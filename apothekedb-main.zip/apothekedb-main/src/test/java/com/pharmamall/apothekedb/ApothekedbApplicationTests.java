package com.pharmamall.apothekedb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApothekedbApplicationTests {

    @Test
    void contextLoads() {
    }

}
