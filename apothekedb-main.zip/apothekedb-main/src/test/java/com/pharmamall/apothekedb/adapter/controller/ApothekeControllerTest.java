package com.pharmamall.apothekedb.adapter.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.pharmamall.apothekedb.application.filter.ApothekeFilter;
import com.pharmamall.apothekedb.application.filter.ApothekeFilterParam;
import com.pharmamall.apothekedb.application.port.dto.ApothekeDTO;
import com.pharmamall.apothekedb.application.port.in.ApothekeUseCase;
import com.pharmamall.apothekedb.application.port.in.InhaberUseCase;


import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
public class ApothekeControllerTest {

    @InjectMocks
    private ApothekeController apothekeController;

    @Mock
    private ApothekeUseCase apothekeUseCase;

    @Mock
    private InhaberUseCase inhaberUseCase;

    private ApothekeDTO apothekeDTO;

    @BeforeEach
    void setUp() {

        apothekeDTO = TestDataGenerator.generateApothekeDTO();
    }

    @Test
    void registerApothekeTest() {

        doNothing().when(apothekeUseCase).createApotheke(any(ApothekeDTO.class));
        ResponseEntity<Map<String, Boolean>> responseEntity = apothekeController.registerApotheke(apothekeDTO);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        String message = "";
        Boolean status= false;
        for (String key:responseEntity.getBody().keySet()) {
            message = key;
            status = responseEntity.getBody().get(key);
        }

        assertTrue(message.equals("Apotheke ist erfolgreich erstellt!") && status);
    }

    @Test
    void getApothekeTest() {

        when(apothekeUseCase.findById(111L)).thenReturn(apothekeDTO);
        ResponseEntity<ApothekeDTO> responseEntity = apothekeController.getApotheke(111L);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody().equals(apothekeDTO));

    }

    @Test
    void getAllApothekenTest() {

        when(apothekeUseCase.fetchAllApotheken()).thenReturn(TestDataGenerator.generateApothekeDTOList());
        ResponseEntity<List<ApothekeDTO>> responseEntity = apothekeController.getAllApotheken();
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody().size()==3);

    }

    @Test
    void updateApothekeTest() {

        doNothing().when(apothekeUseCase).updateApotheke(111L, apothekeDTO);
        ResponseEntity<Map<String, Boolean>> responseEntity = apothekeController.updateApotheke(111L, apothekeDTO);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        String message = "";
        Boolean status= false;
        for (String key:responseEntity.getBody().keySet()) {
            message = key;
            status = responseEntity.getBody().get(key);
        }

        assertTrue(message.equals("erfolgreich!") && status);
    }

    @Test
    void deleteApothekeTest() {

        doNothing().when(apothekeUseCase).removeById(111L);
        ResponseEntity<Map<String, Boolean>> responseEntity = apothekeController.deleteApotheke(111L);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        String message = "";
        Boolean status= false;
        for (String key:responseEntity.getBody().keySet()) {
            message = key;
            status = responseEntity.getBody().get(key);
        }

        assertTrue(message.equals("erfolgreich!") && status);
    }


    @Test
    void deleteInhaberTest() {

        doNothing().when(inhaberUseCase).removeInhaberById(111L, 222L);
        ResponseEntity<Map<String, Boolean>> responseEntity = apothekeController.deleteInhaber(111L, 222L);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        String message = "";
        Boolean status= false;
        for (String key:responseEntity.getBody().keySet()) {
            message = key;
            status = responseEntity.getBody().get(key);
        }

        assertTrue(message.equals("erfolgreich!") && status);
    }

    @Test
    void filterWithValueTest() {
        List<ApothekeDTO> apothekeDTOList = TestDataGenerator.generateApothekeDTOList();
        apothekeDTOList.get(0).setName("Test Apotheke");
        ApothekeFilter apothekeFilter = new ApothekeFilter(ApothekeFilterParam.NAME, "test");
        when(apothekeUseCase.fetchAllApothekenWithValue(apothekeFilter)).thenReturn(apothekeDTOList);
        ResponseEntity<List<ApothekeDTO>> responseEntity = apothekeController.filterWithValue(apothekeFilter);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody().size()>=1);
    }
}
