package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.adapter.storage.entity.ValidationEntity;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ValidationMapperTest {

    @InjectMocks
    private ValidationMapper validationMapper;

    private Validation validation;
    private ValidationEntity validationEntity;

    @BeforeEach
    void setUp() {
        validation = TestDataGenerator.generateValidation();
        validationEntity = TestDataGenerator.buildValidationEntityFromValidation(validation);
    }

    @Test
    void mapToValidationEntityTest() {

        var mapToValidationEntity = validationMapper.mapToValidationEntity(validation);
        assertTrue(mapToValidationEntity.getClass()== ValidationEntity.class);

        validation = null;

        mapToValidationEntity = validationMapper.mapToValidationEntity(validation);
        assertNull(mapToValidationEntity);
    }

    @Test
    void mapToValidationTest() {

        var mapToValidation = validationMapper.mapToValidation(validationEntity);
        assertTrue(mapToValidation.getClass()== Validation.class);

        validationEntity = null;

        mapToValidation = validationMapper.mapToValidation(validationEntity);
        assertNull(mapToValidation);
    }

    @Test
    void mapToValidationListTest() {
        List<ValidationEntity> validationEntityList = List.of(validationEntity);
        var result = validationMapper.mapToValidationList(validationEntityList);
        assertEquals(validationEntityList.size(), result.size());
    }
}
