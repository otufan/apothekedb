package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.adapter.storage.entity.InhaberEntity;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class InhaberMapperTest {

    @InjectMocks
    private InhaberMapper inhaberMapper;

    private Inhaber inhaber;
    private InhaberEntity inhaberEntity;

    @BeforeEach
    void setUp() {
        inhaber = TestDataGenerator.generateInhaber();
        inhaberEntity = TestDataGenerator.buildInhaberEntityFromInhaber(inhaber);
    }

    @Test
    void mapToInhaberEntityTest() {

        var mapToInhaberEntity = inhaberMapper.mapToInhaberEntity(inhaber);
        assertTrue(mapToInhaberEntity.getClass()== InhaberEntity.class);

        inhaber = null;

        mapToInhaberEntity = inhaberMapper.mapToInhaberEntity(inhaber);
        assertNull(mapToInhaberEntity);
    }

    @Test
    void mapToInhaberEntityListTest() {

        List<Inhaber> inhaberList = List.of(inhaber);
        var result = inhaberMapper.mapToInhaberEntityList(inhaberList);
        assertEquals(inhaberList.size(), result.size());
    }

    @Test
    void mapToInhaberTest() {

        var mapToInhaber = inhaberMapper.mapToInhaber(inhaberEntity);
        assertTrue(mapToInhaber.getClass()== Inhaber.class);

        inhaberEntity = null;

        mapToInhaber = inhaberMapper.mapToInhaber(inhaberEntity);
        assertNull(mapToInhaber);
    }

    @Test
    void mapToInhaberListTest() {

        List<InhaberEntity> inhaberEntityList = List.of(inhaberEntity);
        var result = inhaberMapper.mapToInhaberList(inhaberEntityList);
        assertEquals(inhaberEntityList.size(), result.size());

    }
}
