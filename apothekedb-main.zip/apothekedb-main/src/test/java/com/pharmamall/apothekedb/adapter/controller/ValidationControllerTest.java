package com.pharmamall.apothekedb.adapter.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.pharmamall.apothekedb.application.port.dto.ValidationDTO;
import com.pharmamall.apothekedb.application.port.in.ValidationUseCase;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
public class ValidationControllerTest {

    @InjectMocks
    private ValidationController validationController;

    @Mock
    private ValidationUseCase validationUseCase;

    private ValidationDTO validationDTO;

    @BeforeEach
    void setUp() {

        validationDTO = TestDataGenerator.generateValidationDTO();
    }
    @Test
    void validateApothekeTest() {

        doNothing().when(validationUseCase).validateApotheke(validationDTO, 111L);
        ResponseEntity<Map<String, Boolean>> responseEntity = validationController.validateApotheke(111L, validationDTO);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        String message = "";
        Boolean status= false;
        for (String key:responseEntity.getBody().keySet()) {
            message = key;
            status = responseEntity.getBody().get(key);
        }

        assertTrue(message.equals("Validation ist erfolgreich hinzugefügt!") && status);
    }

    @Test
    void getAllValidationTest() {

        when(validationUseCase.fetchAllValidation()).thenReturn(TestDataGenerator.generateValidationDTOList());
        ResponseEntity<List<ValidationDTO>> responseEntity = validationController.getAllValidation();
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody().size()==3);

    }

    @Test
    void deleteValidationTest() {

        doNothing().when(validationUseCase).removeValidation(333L);
        ResponseEntity<Map<String, Boolean>> responseEntity = validationController.deleteValidation(333L);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        String message = "";
        Boolean status= false;
        for (String key:responseEntity.getBody().keySet()) {
            message = key;
            status = responseEntity.getBody().get(key);
        }

        assertTrue(message.equals("erfolgreich!") && status);
    }
}
