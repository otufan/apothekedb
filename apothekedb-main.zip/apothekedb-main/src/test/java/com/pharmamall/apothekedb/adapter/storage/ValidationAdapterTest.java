package com.pharmamall.apothekedb.adapter.storage;

import static org.mockito.Mockito.*;

import com.pharmamall.apothekedb.adapter.storage.entity.ValidationEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ApothekeMapper;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ValidationMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.ValidationRepository;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ValidationAdapterTest {

    @Mock
    private ValidationRepository repository;

    @Mock
    private ValidationMapper validationMapper;

    @Mock
    private ApothekeMapper apothekeMapper;

    @InjectMocks
    private ValidationAdapter validationAdapter;

    private Long validationId;
    private Validation validation;
    private ValidationEntity validationEntity;
    private Apotheke apotheke;
    private Long apothekeId;

    @BeforeEach
    void setUp() {
        validationId = 333L;
        validation = TestDataGenerator.generateValidation();
        validationEntity = TestDataGenerator.buildValidationEntityFromValidation(validation);
        apotheke = TestDataGenerator.generateApotheke();
        apothekeId = 111L;
    }

    @Test
    void saveTest() {

        validationEntity.setId(validationId);
        when(repository.save(validationMapper.mapToValidationEntity(validation))).thenReturn(validationEntity);
        validationAdapter.save(validation, apotheke);
        verify(repository, times(1)).save(validationMapper.mapToValidationEntity(validation));
        verify(repository, times(1)).setApotheke(validationId, apothekeMapper.mapToApothekeEntity(apotheke));

    }

    @Test
    void findAllValidationTest() {
        validationAdapter.findAllValidation();
        verify(repository, times(1)).findAll();

    }
    @Test
    void findByIdTest() {
        when(repository.findById(validationId)).thenReturn(Optional.of(validationEntity));
        validationAdapter.findById(validationId);
        verify(repository, times(1)).findById(eq(validationId));
    }

    @Test
    void deleteByIdTest() {
        validationAdapter.deleteById(validationId);
        verify(repository, times(1)).deleteById(eq(validationId));
    }

    @Test
    void findValidationByApothekeIdTest() {

        validationAdapter.findValidationByApothekeId(apothekeId);
        verify(repository, times(1)).findValidationByApothekeId(apothekeId);

    }
}
