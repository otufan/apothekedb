package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.adapter.storage.entity.ApothekeEntity;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ApothekeMapperTest {

    @InjectMocks
    private ApothekeMapper apothekeMapper;

    private Apotheke apotheke;
    private ApothekeEntity apothekeEntity;

    @BeforeEach
    void setUp() {
        apotheke = TestDataGenerator.generateApotheke();
        apothekeEntity = TestDataGenerator.buildApothekeEntityFromApotheke(apotheke);
    }

    @Test
    void mapToApothekeEntityTest() {

        var mapToApothekeEntity = apothekeMapper.mapToApothekeEntity(apotheke);
        assertTrue(mapToApothekeEntity.getClass()==ApothekeEntity.class);

        apotheke = null;

        mapToApothekeEntity = apothekeMapper.mapToApothekeEntity(apotheke);
        assertNull(mapToApothekeEntity);

    }

    @Test
    void mapToApothekeTest() {

        var mapToApotheke = apothekeMapper.mapToApotheke(apothekeEntity);
        assertTrue(mapToApotheke.getClass() == Apotheke.class);

        apothekeEntity = null;

        mapToApotheke = apothekeMapper.mapToApotheke(apothekeEntity);
        assertNull(mapToApotheke);

    }

    @Test
    void mapToApothekeListTest() {
        List<ApothekeEntity> apothekeEntityList = List.of(apothekeEntity);
        var result = apothekeMapper.mapToApothekeList(apothekeEntityList);
        assertEquals(apothekeEntityList.size(), result.size());

    }
}
