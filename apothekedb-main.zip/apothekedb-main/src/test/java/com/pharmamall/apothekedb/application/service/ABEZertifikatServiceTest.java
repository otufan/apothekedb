package com.pharmamall.apothekedb.application.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.application.port.out.ABEZertifikatPort;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;


@ExtendWith(MockitoExtension.class)
public class ABEZertifikatServiceTest {

    @Mock
    private ABEZertifikatPort abeZertifikatPort;

    @Mock
    private ApothekePort apothekePort;

    @InjectMocks
    private ABEZertifikatService abeZertifikatService;

    private Long abeZertifikatId;
    private Long apothekeId;
    private ABEZertifikat abeZertifikat;
    private MultipartFile zertifikat;




    @BeforeEach
    void setUp() throws IOException {

        abeZertifikatId = 444L;
        apothekeId = 111L;
        abeZertifikat = TestDataGenerator.generateAbeZertifikat();
        String filePath = "src/testint/resources/test_abe_zertifikat.jpg";
        byte[] bytes = Files.readAllBytes(Paths.get(filePath));
        zertifikat = new MockMultipartFile("zertifikat",
                "test_abe_zertifikat.jpg",
                "image/JPEG",
                bytes);

    }

    @Test
    void getZertifikatByIdTest() {

        abeZertifikat.setId(abeZertifikatId);
        when(abeZertifikatPort.findById(abeZertifikatId)).thenReturn(abeZertifikat);
        ABEZertifikat result = abeZertifikatService.getZertifikatById(abeZertifikatId);
        assertEquals(result, abeZertifikat);


    }

    @Test
    void storeNewABEZertifikatTest() throws IOException {

        Apotheke apotheke = TestDataGenerator.generateApotheke();
        apotheke.setId(apothekeId);
        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        when(abeZertifikatPort.findABEZertifikatByApothekeId(apothekeId)).thenReturn(null);
        abeZertifikatService.store(zertifikat, apothekeId);
        verify(abeZertifikatPort, times(1)).findABEZertifikatByApothekeId(apothekeId);



    }

    @Test
    void storeWithUpdatingTest() throws IOException {

        Apotheke apotheke = TestDataGenerator.generateApotheke();
        apotheke.setId(apothekeId);

        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        when(abeZertifikatPort.findABEZertifikatByApothekeId(apothekeId)).thenReturn(abeZertifikat);

        abeZertifikatService.store(zertifikat, apothekeId);
        ABEZertifikat abeZertifikatUpdate = ABEZertifikat.builder().
                name(apotheke.getName() +"_"+ LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))).
                type(zertifikat.getContentType()).
                data(zertifikat.getBytes()).
                build();

        verify(abeZertifikatPort, times(2)).findABEZertifikatByApothekeId(apothekeId);
        verify(abeZertifikatPort, times(1)).setApothekeInABEZertifikat(abeZertifikatUpdate, apotheke);
    }

    @Test
    void fetchAllAbeZertifikateTest() {
        abeZertifikatService.fetchAllAbeZertifikate();
        verify(abeZertifikatPort, times(1)).findAll();

    }
}
