package com.pharmamall.apothekedb.application.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.application.port.dto.ValidationDTO;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.application.port.out.ValidationPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ValidationServiceTest {

    @Mock
    private ValidationPort validationPort;

    @Mock
    private ApothekePort apothekePort;

    @InjectMocks
    private ValidationService validationService;

    private Long apothekeId;
    private Long validationId;
    private Apotheke apotheke;
    private ValidationDTO validationDTO;
    private Validation validation;
    private List<Validation> validationList;

    @BeforeEach
    void setUp() {
        apothekeId = 111L;
        validationId = 333L;
        apotheke = TestDataGenerator.generateApotheke();
        validationDTO = TestDataGenerator.generateValidationDTO();
        validation = TestDataGenerator.generateValidation();
        validationList = TestDataGenerator.generateValidationList();
    }
    @Test
    void validateApothekeTest() {

        apotheke.setId(apothekeId);

        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        when(validationPort.findValidationByApothekeId(apothekeId)).thenReturn(null);

        validationService.validateApotheke(validationDTO, apothekeId);

        verify(apothekePort, times(1)).findById(eq(apothekeId));
        verify(validationPort, times(1)).findValidationByApothekeId(eq(apothekeId));

    }

    @Test
    void validateExistingApothekeTest() {

        apotheke.setId(apothekeId);

        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        when(validationPort.findValidationByApothekeId(apothekeId)).thenReturn(validation);

        validationService.validateApotheke(validationDTO, apothekeId);

        verify(apothekePort, times(1)).findById(eq(apothekeId));
        verify(validationPort, times(2)).findValidationByApothekeId(eq(apothekeId));
        validation = TestDataGenerator.buildValidationFromValidationDTO(validationDTO);


    }

    @Test
    void fetchAllValidationTest() {

        when(validationPort.findAllValidation()).thenReturn(validationList);
        List<ValidationDTO> resultList = validationService.fetchAllValidation();
        assertEquals(validationList.size(), resultList.size());
    }

    @Test
    void removeValidationTest() {

        validation.setId(validationId);
        when(validationPort.findById(validationId)).thenReturn(validation);

        validationService.removeValidation(validationId);

        verify(validationPort, times(1)).findById(eq(validationId));
        verify(validationPort, times(1)).deleteById(eq(validationId));

    }
}
