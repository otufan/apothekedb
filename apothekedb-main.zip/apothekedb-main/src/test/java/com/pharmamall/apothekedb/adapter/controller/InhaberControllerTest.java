package com.pharmamall.apothekedb.adapter.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;
import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.in.InhaberUseCase;

import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


@ExtendWith(MockitoExtension.class)
public class InhaberControllerTest {

    @InjectMocks
    private InhaberController inhaberController;

    @Mock
    private InhaberUseCase inhaberUseCase;

    private InhaberDTO inhaberDTO;

    @BeforeEach
    void setUp() {

        inhaberDTO = TestDataGenerator.generateInhaberDTO();
    }

    @Test
    void registerInhaberTest() {

        when(inhaberUseCase.createInhaber(inhaberDTO, 111L)).thenReturn(TestDataGenerator.buildInhaberFromInhaberDTO(inhaberDTO));
        ResponseEntity<Map<String, Boolean>> responseEntity = inhaberController.registerInhaber(inhaberDTO, 111L);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        String message = "";
        Boolean status= false;
        for (String key:responseEntity.getBody().keySet()) {
            message = key;
            status = responseEntity.getBody().get(key);
        }

        assertTrue(message.equals("Inhaber ist erfolgreich erstellt!") && status);

    }

    @Test
    void getInhaberTest() {

        when(inhaberUseCase.findById(222L)).thenReturn(inhaberDTO);
        ResponseEntity<InhaberDTO> responseEntity = inhaberController.getInhaber(222L);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody().equals(inhaberDTO));
    }

    @Test
    void getAllInhabersTest() {

        when(inhaberUseCase.fetchAllInhabers()).thenReturn(TestDataGenerator.generateInhaberDTOList());
        ResponseEntity<List<InhaberDTO>> responseEntity = inhaberController.getAllInhabers();
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(responseEntity.getBody().size()==3);

    }
    @Test
    void updateInhaberTest() {

        when(inhaberUseCase.updateInhaber(222L, inhaberDTO)).thenReturn(TestDataGenerator.buildInhaberFromInhaberDTO(inhaberDTO));
        ResponseEntity<Map<String, Boolean>> responseEntity = inhaberController.updateInhaber(222L, inhaberDTO);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        String message = "";
        Boolean status= false;
        for (String key:responseEntity.getBody().keySet()) {
            message = key;
            status = responseEntity.getBody().get(key);
        }

        assertTrue(message.equals("erfolgreich") && status);

    }
}
