package com.pharmamall.apothekedb.application.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.application.filter.ApothekeFilter;
import com.pharmamall.apothekedb.application.filter.ApothekeFilterParam;
import com.pharmamall.apothekedb.application.port.dto.ApothekeDTO;
import com.pharmamall.apothekedb.application.port.exception.ConflictException;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
public class ApothekeServiceTest {

    @Mock
    private ApothekePort apothekePort;
    @InjectMocks
    private ApothekeService apothekeService;

    private Long apothekeId;
    private Apotheke apotheke;
    private ApothekeDTO apothekeDTO;
    private Apotheke apothekeDetails;
    private  List<Apotheke> apothekeList;


    @BeforeEach
    void setUp() {
        apothekeId = 111L;
        apotheke = TestDataGenerator.generateApotheke();
        apothekeDTO = TestDataGenerator.generateApothekeDTO();
        apothekeDetails = TestDataGenerator.generateApotheke();
        apothekeList = TestDataGenerator.generateApothekeList();

    }

    @Test
    void createApothekeTest() {

        when(apothekePort.existsByEmail(apothekeDTO.getEmail())).thenReturn(false);
        apothekeService.createApotheke(apothekeDTO);
        apotheke = TestDataGenerator.buildApothekeFromApothekeDTO(apothekeDTO);
        verify(apothekePort, times(1)).existsByEmail(apothekeDTO.getEmail());


    }

    @Test
    void createApothekeWithExistingEmailTest() {

        when(apothekePort.existsByEmail(apothekeDTO.getEmail())).thenReturn(true);
        var conflictException = assertThrows(ConflictException.class, ()->apothekeService.createApotheke(apothekeDTO));
        assertEquals("E-Mail ist bereits vorhanden", conflictException.getMessage());
    }


    @Test
    void findByIdTest() {

        apotheke = TestDataGenerator.buildApothekeFromApothekeDTO(apothekeDTO);
        apotheke.setId(apothekeId);
        apotheke.setInhabers(List.of(TestDataGenerator.generateInhaber()));
        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        ApothekeDTO result = apothekeService.findById(apothekeId);
        assertTrue(result.getClass()==ApothekeDTO.class && result !=null);
        verify(apothekePort, times(1)).findById(eq(apothekeId));
    }

    @Test
    void updateApothekeTest() {

        Apotheke apotheke = TestDataGenerator.buildApothekeFromApothekeDTO(apothekeDTO);
        apotheke.setId(apothekeId);

        when(apothekePort.existsByEmail(apothekeDTO.getEmail())).thenReturn(false);
        when(apothekePort.findById(apothekeId)).thenReturn(apothekeDetails);

        apothekeService.updateApotheke(apothekeId, apothekeDTO);

        verify(apothekePort, times(1)).existsByEmail(apothekeDTO.getEmail());
        verify(apothekePort, times(1)).findById(apothekeId);


    }

    @Test
    void updateApothekeWithExistingEmailTest() {

        when(apothekePort.existsByEmail(apothekeDTO.getEmail())).thenReturn(true);
        when(apothekePort.findById(apothekeId)).thenReturn(apothekeDetails);

        var conflictException = assertThrows(ConflictException.class,
                ()->apothekeService.updateApotheke(apothekeId, apothekeDTO));
        assertEquals("E-Mail ist bereits vorhanden", conflictException.getMessage());
    }

    @Test
    void removeByIdTest() {

        apotheke.setId(apothekeId);
        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        apothekeService.removeById(apothekeId);
        verify(apothekePort,times(1)).deleteById(apothekeId);

    }

    @Test
    void fetchAllApothekenTest() {

        when(apothekePort.findAll()).thenReturn(apothekeList);
        List<ApothekeDTO> apothekeDTOList = apothekeService.fetchAllApotheken();
        verify(apothekePort, times(1)).findAll();
        assertEquals(apothekeDTOList.size(), apothekeList.size());
    }

    @Test
    void fetchAllApothekenWithNameTest() {

        ApothekeFilter apothekeFilter = new ApothekeFilter(ApothekeFilterParam.NAME, "test");
        apotheke.setName("test");
        List<Apotheke> apothekeList = List.of(apotheke);
        when(apothekePort.findByNameWithValue("test")).thenReturn(apothekeList);
        List<ApothekeDTO> result = apothekeService.fetchAllApothekenWithValue(apothekeFilter);
        verify(apothekePort, times(1)).findByNameWithValue("test");
        assertEquals(apothekeList.size(), result.size());

    }

    @Test
    void fetchAllApothekenWithStrasseTest() {

        ApothekeFilter apothekeFilter = new ApothekeFilter(ApothekeFilterParam.STRASSE, "test str.");

        apotheke.setStrasse("test str.");
        List<Apotheke> apothekeList = List.of(apotheke);
        when(apothekePort.findByStrasseWithValue(apothekeFilter.getValue())).thenReturn(apothekeList);
        List<ApothekeDTO> result = apothekeService.fetchAllApothekenWithValue(apothekeFilter);
        verify(apothekePort, times(1)).findByStrasseWithValue(apothekeFilter.getValue());
        assertEquals(apothekeList.size(), result.size());

    }

    @Test
    void fetchAllApothekenWithPLZTest() {

        ApothekeFilter apothekeFilter = new ApothekeFilter(ApothekeFilterParam.PLZ, "50111");

        apotheke.setPlz(apothekeFilter.getValue());
        List<Apotheke> apothekeList = List.of(apotheke);
        when(apothekePort.findByPlzWithValue(apothekeFilter.getValue())).thenReturn(apothekeList);
        List<ApothekeDTO> result = apothekeService.fetchAllApothekenWithValue(apothekeFilter);
        verify(apothekePort, times(1)).findByPlzWithValue(apothekeFilter.getValue());
        assertEquals(apothekeList.size(), result.size());

    }

    @Test
    void fetchAllApothekenWithOrtTest() {

        ApothekeFilter apothekeFilter = new ApothekeFilter(ApothekeFilterParam.ORT, "Koeln");

        apotheke.setOrt(apothekeFilter.getValue());
        List<Apotheke> apothekeList = List.of(apotheke);
        when(apothekePort.findByOrtWithValue(apothekeFilter.getValue())).thenReturn(apothekeList);
        List<ApothekeDTO> result = apothekeService.fetchAllApothekenWithValue(apothekeFilter);
        verify(apothekePort, times(1)).findByOrtWithValue(apothekeFilter.getValue());
        assertEquals(apothekeList.size(), result.size());

    }

    @Test
    void fetchAllApothekenWithEmailTest() {

        ApothekeFilter apothekeFilter = new ApothekeFilter(ApothekeFilterParam.EMAIL, "test@mail.de");

        apotheke.setEmail(apothekeFilter.getValue());
        List<Apotheke> apothekeList = List.of(apotheke);
        when(apothekePort.findByEmailWithValue(apothekeFilter.getValue())).thenReturn(apothekeList);
        List<ApothekeDTO> result = apothekeService.fetchAllApothekenWithValue(apothekeFilter);
        verify(apothekePort, times(1)).findByEmailWithValue(apothekeFilter.getValue());
        assertEquals(apothekeList.size(), result.size());

    }
}
























