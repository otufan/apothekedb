package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.adapter.storage.entity.ABEZertifikatEntity;
import com.pharmamall.apothekedb.domain.ABEZertifikat;

import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ABEZertifikatMapperTest {


    @InjectMocks
    private ABEZertifikatMapper abeZertifikatMapper;

    private ABEZertifikatEntity abeZertifikatEntity;

    private ABEZertifikat abeZertifikat;

    @BeforeEach
    void setUp() {
        abeZertifikatEntity = TestDataGenerator.generateAbeZertifikatEntity();
        abeZertifikat = TestDataGenerator.generateAbeZertifikat();

    }
    @Test
    void mapToABEZertifikatTest() {

        var mapToABEZertifikat = abeZertifikatMapper.mapToABEZertifikat(abeZertifikatEntity);
        assertTrue(mapToABEZertifikat.getClass()== ABEZertifikat.class);

        abeZertifikatEntity = null;

        var result = abeZertifikatMapper.mapToABEZertifikat(abeZertifikatEntity);
        assertNull(result);
    }

    @Test
    void mapToABEZertifikatListTest() {

        List<ABEZertifikatEntity> abeZertifikatEntityList = List.of(abeZertifikatEntity);
        var result = abeZertifikatMapper.mapToABEZertifikatList(abeZertifikatEntityList);
        assertEquals(abeZertifikatEntityList.size(), result.size());

    }

    @Test
    void mapToABEZertifikatEntityTest() {

        var mapToABEZertifikatEntity = abeZertifikatMapper.mapToABEZertifikatEntity(abeZertifikat);
        assertTrue(mapToABEZertifikatEntity.getClass()== ABEZertifikatEntity.class);

        abeZertifikat = null;

        var result = abeZertifikatMapper.mapToABEZertifikatEntity(abeZertifikat);
        assertNull(result);
    }


}
