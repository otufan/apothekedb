package com.pharmamall.apothekedb.adapter.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.pharmamall.apothekedb.application.port.dto.ABEZertifikatDTO;
import com.pharmamall.apothekedb.application.port.in.ABEZertifikatUseCase;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;


@ExtendWith(MockitoExtension.class)
public class ABEZertifikatControllerTest {

    @InjectMocks
    private ABEZertifikatController abeZertifikatController;

    @Mock
    private ABEZertifikatUseCase abeZertifikatUseCase;

    private ABEZertifikat abeZertifikat;

    private MultipartFile zertifikat;

    @BeforeEach
    void setUp() throws IOException {

        abeZertifikat = TestDataGenerator.generateAbeZertifikat();
        String filePath = "src/testint/resources/test_abe_zertifikat.jpg";
        byte[] bytes = Files.readAllBytes(Paths.get(filePath));
        zertifikat = new MockMultipartFile("zertifikat",
                "test_abe_zertifikat.jpg",
                "image/JPEG",
                bytes);

    }

    @Test
    void uploadAbeZertifikatTest() throws IOException {

        when(abeZertifikatUseCase.store(zertifikat, 444L)).thenReturn(abeZertifikat);
        ResponseEntity<Map<String, String>> responseEntity = abeZertifikatController.uploadAbeZertifikat(444L, zertifikat);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.CREATED);

    }

    @Test
    void uploadAbeZertifikatWithIOExceptionTest() throws IOException {

        when(abeZertifikatUseCase.store(zertifikat, 444L)).thenThrow(new IOException());
        ResponseEntity<Map<String, String>> responseEntity = abeZertifikatController.uploadAbeZertifikat(444L, zertifikat);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.EXPECTATION_FAILED);

        String text= "";
        for (String key:responseEntity.getBody().keySet()) {
            text = responseEntity.getBody().get(key);
        }
        assertTrue(text.contains("konnte die Datei nicht hochladen:"));

    }

    @Test
    void downloadAbeZertifikatTest() {

        when(abeZertifikatUseCase.getZertifikatById(444L)).thenReturn(abeZertifikat);
        ResponseEntity<byte[]> responseEntity = abeZertifikatController.downloadAbeZertifikat(444L);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertTrue(responseEntity.getBody().length==50);
    }

    @Test
    void getAllAbeZertifikatTest() {

        when(abeZertifikatUseCase.fetchAllAbeZertifikate()).thenReturn(TestDataGenerator.generateAbeZertifikatDTOList());
        ResponseEntity<List<ABEZertifikatDTO>> responseEntity = abeZertifikatController.getAllAbeZertifikat();
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertTrue(responseEntity.getBody().size()==3);
    }

    @Test
    void displayAbeZertifikatTest() {

        when(abeZertifikatUseCase.getZertifikatById(444L)).thenReturn(abeZertifikat);
        ResponseEntity<byte[]> responseEntity = abeZertifikatController.displayAbeZertifikat(444L);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertTrue(responseEntity.getBody() != null);

    }
}
