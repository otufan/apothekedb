package com.pharmamall.apothekedb.adapter.storage;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;


import com.pharmamall.apothekedb.adapter.storage.entity.ApothekeEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ApothekeMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.ApothekeRepository;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ApothekeAdapterTest {

    @Mock
    private ApothekeRepository repository;

    @Mock
    private ApothekeMapper mapper;
    @InjectMocks
    ApothekeAdapter apothekeAdapter;

    private Long apothekeId;
    private Apotheke apotheke;

    private ApothekeEntity apothekeEntity;
    private List<Apotheke> apothekeList;

    @BeforeEach
    void setUp() {
        apothekeId = 111L;
        apotheke = TestDataGenerator.generateApotheke();
        apothekeEntity = TestDataGenerator.buildApothekeEntityFromApotheke(apotheke);
        apothekeList = TestDataGenerator.generateApothekeList();

    }

    @Test
    void writeTest() {
        apothekeAdapter.write(apotheke);
        verify(repository, times(1)).save(mapper.mapToApothekeEntity(eq(apotheke)));
    }

    @Test
    void existsByEmailTest() {
        apothekeAdapter.existsByEmail(apotheke.getEmail());
        verify(repository, times(1)).existsByEmail(eq(apotheke.getEmail()));
    }

    @Test
    void findByIdTest() {

        apothekeEntity.setId(apothekeId);
        when(repository.findById(apothekeId)).thenReturn(Optional.of(apothekeEntity));
        apothekeAdapter.findById(apothekeId);
        verify(repository, times(1)).findById(eq(apothekeId));
    }

    @Test
    void findByIdWithExceptionTest() {

        apothekeEntity.setId(apothekeId);
        var resourceNotFoundException = assertThrows(ResourceNotFoundException.class, ()->apothekeAdapter.findById(apothekeId));
        assertEquals("Apotheke mit id 111 ist nicht gefunden", resourceNotFoundException.getMessage());

    }

    @Test
    void deleteByIdTest() {
        apothekeAdapter.deleteById(apothekeId);
        verify(repository, times(1)).deleteById(eq(apothekeId));
    }

    @Test
    void findAllTest() {
        List<ApothekeEntity> apothekeEntityList = apothekeList.stream().
                map(TestDataGenerator::buildApothekeEntityFromApotheke).
                collect(Collectors.toList());
        when(repository.findAll()).thenReturn(apothekeEntityList);
        apothekeAdapter.findAll();
        verify(repository, times(1)).findAll();
    }

    @Test
    void findByNameWithValueTest() {
        apothekeAdapter.findByNameWithValue(apotheke.getName());
        verify(repository, times(1)).findByNameWithValue(eq(apotheke.getName()));
    }

    @Test
    void findByStrasseWithValueTest() {
        apothekeAdapter.findByStrasseWithValue(apotheke.getStrasse());
        verify(repository, times(1)).findByStrasseWithValue(eq(apotheke.getStrasse()));
    }

    @Test
    void findByPlzWithValueTest() {
        apothekeAdapter.findByPlzWithValue(apotheke.getPlz());
        verify(repository, times(1)).findByPlzWithValue(eq(apotheke.getPlz()));
    }

    @Test
    void findByOrtWithValueTest() {
        apothekeAdapter.findByOrtWithValue(apotheke.getOrt());
        verify(repository, times(1)).findByOrtWithValue(eq(apotheke.getOrt()));
    }

    @Test
    void findByEmailWithValueTest() {
        apothekeAdapter.findByEmailWithValue(apotheke.getEmail());
        verify(repository, times(1)).findByEmailWithValue(eq(apotheke.getEmail()));
    }
}
