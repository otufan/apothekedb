package com.pharmamall.apothekedb.adapter.storage;

import static org.mockito.Mockito.*;

import com.pharmamall.apothekedb.adapter.storage.entity.ABEZertifikatEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ABEZertifikatMapper;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ApothekeMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.ABEZertifikatRepository;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ABEZertifikatAdapterTest {

    @Mock
    private ABEZertifikatRepository repository;

    @Mock
    private ApothekeMapper apothekeMapper;

    @Mock
    private ABEZertifikatMapper abeZertifikatMapper;

    @InjectMocks
    private ABEZertifikatAdapter abeZertifikatAdapter;

    private Long abeZertifikatId;
    private Long apothekeId;
    private ABEZertifikatEntity abeZertifikatEntity;

    private ABEZertifikat abeZertifikat;

    private Apotheke apotheke;

    @BeforeEach
    void setUp() {
        abeZertifikatId = 444L;
        apothekeId = 111L;
        abeZertifikatEntity = TestDataGenerator.generateAbeZertifikatEntity();
        abeZertifikat = TestDataGenerator.generateAbeZertifikat();
        apotheke = TestDataGenerator.generateApotheke();
    }


    @Test
    void findByIdTest() {

        abeZertifikatEntity.setId(abeZertifikatId);
        when(repository.findById(abeZertifikatId)).thenReturn(Optional.of(abeZertifikatEntity));
        abeZertifikatAdapter.findById(abeZertifikatId);
        verify(repository, times(1)).findById(eq(abeZertifikatId));
    }

    @Test
    void saveTest() {
        abeZertifikat = abeZertifikatAdapter.save(abeZertifikat);
        abeZertifikatEntity = abeZertifikatMapper.mapToABEZertifikatEntity(abeZertifikat);
        verify(repository, times(1)).save(eq(abeZertifikatEntity));

    }

    @Test
    void findAllTest() {
        abeZertifikatAdapter.findAll();
        verify(repository, times(1)).findAll();
    }

    @Test
    void setApothekeTest() {
        abeZertifikat.setId(abeZertifikatId);
        abeZertifikatAdapter.setApothekeInABEZertifikat(abeZertifikat, apotheke);
        verify(repository, times(1)).setApothekeInABEZertifikat(abeZertifikat.getId(), apothekeMapper.mapToApothekeEntity(apotheke));
    }

    @Test
    void findABEZertifikatByApothekeIdTest() {
        abeZertifikatAdapter.findABEZertifikatByApothekeId(apothekeId);
        verify(repository, times(1)).findABEZertifikatByApothekeId(eq(apothekeId));
    }
}
