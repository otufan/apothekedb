package com.pharmamall.apothekedb.testdata;

import com.github.javafaker.Faker;
import com.pharmamall.apothekedb.adapter.storage.entity.ABEZertifikatEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.ApothekeEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.InhaberEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.ValidationEntity;
import com.pharmamall.apothekedb.application.port.dto.ABEZertifikatDTO;
import com.pharmamall.apothekedb.application.port.dto.ApothekeDTO;
import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.dto.ValidationDTO;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.domain.enumeration.ApothekeGruppen;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class TestDataGenerator {

    private static Faker randomData = new Faker();


    public static ApothekeDTO generateApothekeDTO(){
        return ApothekeDTO.builder().
                name(randomData.company().name()).
                strasse(randomData.address().streetAddress()).
                plz(String.valueOf(randomData.number().numberBetween(1000, 99999))).
                ort(randomData.address().city()).
                telefonNummer("(200)-500-2000").
                email(randomData.internet().emailAddress()).
                apothekeGruppe(ApothekeGruppen.GRUPPE_OA).
                build();
    }

    public static Apotheke generateApotheke(){
        List<Inhaber> inhaberList = new ArrayList<>();
        return Apotheke.builder().
                name(randomData.company().name()).
                strasse(randomData.address().streetAddress()).
                plz(String.valueOf(randomData.number().numberBetween(1000, 99999))).
                ort(randomData.address().city()).
                telefonNummer("(200)-500-2000").
                email(randomData.internet().emailAddress()).
                apothekeGruppe(ApothekeGruppen.GRUPPE_OA).
                inhabers(inhaberList).
                build();
    }

    public static Apotheke buildApothekeFromApothekeDTO(ApothekeDTO apothekeDTO) {
        return Apotheke.builder().
                name(apothekeDTO.getName()).
                strasse(apothekeDTO.getStrasse()).
                plz(apothekeDTO.getPlz()).
                ort(apothekeDTO.getOrt()).
                telefonNummer(apothekeDTO.getTelefonNummer()).
                email(apothekeDTO.getEmail()).
                apothekeGruppe(apothekeDTO.getApothekeGruppe()).
                build();
    }

    public static ApothekeEntity buildApothekeEntityFromApotheke(Apotheke apotheke) {
        return ApothekeEntity.builder().
                id(apotheke.getId()).
                name(apotheke.getName()).
                strasse(apotheke.getStrasse()).
                plz(apotheke.getPlz()).
                ort(apotheke.getOrt()).
                telefonNummer(apotheke.getTelefonNummer()).
                email(apotheke.getEmail()).
                apothekeGruppe(apotheke.getApothekeGruppe()).
                build();
    }

    public static InhaberDTO generateInhaberDTO() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate geburtsdatum = LocalDate.parse("1989-04-20", dateTimeFormatter);
        return InhaberDTO.builder().
                vorname(randomData.name().firstName()).
                nachname(randomData.name().lastName()).
                steuerNummer(randomData.internet().emailAddress()).
                geburtsdatum(geburtsdatum).
                geburtsort(randomData.address().city()).
                build();

    }

    public static Inhaber generateInhaber() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate geburtsdatum = LocalDate.parse("1989-04-20", dateTimeFormatter);
        return Inhaber.builder().
                vorname(randomData.name().firstName()).
                nachname(randomData.name().lastName()).
                steuerNummer(String.valueOf(randomData.number().numberBetween(10000, 9999999))).
                geburtsdatum(geburtsdatum).
                geburtsort(randomData.address().city()).
                build();

    }

    public static InhaberDTO buildInhaberDTOFromInhaber(Inhaber inhaber) {
        return InhaberDTO.builder().
                vorname(inhaber.getVorname()).
                nachname(inhaber.getNachname()).
                steuerNummer(inhaber.getSteuerNummer()).
                geburtsdatum(inhaber.getGeburtsdatum()).
                geburtsort(inhaber.getGeburtsort()).
                build();
    }

    public static Inhaber buildInhaberFromInhaberDTO(InhaberDTO inhaberDto) {
        return Inhaber.builder().
                vorname(inhaberDto.getVorname()).
                nachname(inhaberDto.getNachname()).
                steuerNummer(inhaberDto.getSteuerNummer()).
                geburtsdatum(inhaberDto.getGeburtsdatum()).
                geburtsort(inhaberDto.getGeburtsort()).
                build();
    }
    public static InhaberEntity buildInhaberEntityFromInhaber(Inhaber inhaber) {
        return InhaberEntity.builder().
                id(inhaber.getId()).
                vorname(inhaber.getVorname()).
                nachname(inhaber.getNachname()).
                steuerNummer(inhaber.getSteuerNummer()).
                geburtsdatum(inhaber.getGeburtsdatum()).
                geburtsort(inhaber.getGeburtsort()).
                build();
    }

    public static List<Apotheke> generateApothekeList () {
        List<Apotheke> apothekeList = new ArrayList<>();
        apothekeList.add(generateApotheke());
        apothekeList.add(generateApotheke());
        apothekeList.add(generateApotheke());
        return apothekeList;
    }

    public static List<ApothekeDTO> generateApothekeDTOList() {
        List<ApothekeDTO> apothekeDTOList = new ArrayList<>();
        apothekeDTOList.add(generateApothekeDTO());
        apothekeDTOList.add(generateApothekeDTO());
        apothekeDTOList.add(generateApothekeDTO());
        return apothekeDTOList;
    }


    public static List<Inhaber> geberateInhaberList() {
        List<Inhaber> inhaberList = new ArrayList<>();
        inhaberList.add(generateInhaber());
        inhaberList.add(generateInhaber());
        inhaberList.add(generateInhaber());

        return inhaberList;
    }

    public static List<InhaberDTO> generateInhaberDTOList() {

        List<InhaberDTO> inhaberDTOList = new ArrayList<>();
        inhaberDTOList.add(generateInhaberDTO());
        inhaberDTOList.add(generateInhaberDTO());
        inhaberDTOList.add(generateInhaberDTO());
        return inhaberDTOList;
    }

    public static ValidationDTO generateValidationDTO(){
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate validationDatum = LocalDate.parse("2022-12-20", dateTimeFormatter);
        long restTage = ChronoUnit.DAYS.between(validationDatum, LocalDate.now());

        return ValidationDTO.builder().
                validiertVon(randomData.name().fullName()).
                validStatus(true).
                validationDatum(validationDatum).
                restTage(""+restTage).
                build();
    }

    public static Validation generateValidation(){
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate validationDatum = LocalDate.parse("2022-12-20", dateTimeFormatter);
        return Validation.builder().
                validiertVon(randomData.name().fullName()).
                validStatus(true).
                validationDatum(validationDatum).
                build();
    }

    public static List<Validation> generateValidationList(){
        List<Validation> validationList = new ArrayList<>();
        validationList.add(generateValidation());
        validationList.add(generateValidation());
        validationList.add(generateValidation());
        return validationList;

    }

    public static List<ValidationDTO> generateValidationDTOList() {
        List<ValidationDTO> validationDTOList = new ArrayList<>();
        validationDTOList.add(generateValidationDTO());
        validationDTOList.add(generateValidationDTO());
        validationDTOList.add(generateValidationDTO());
        return validationDTOList;
    }

    public static Validation buildValidationFromValidationDTO(ValidationDTO validationDTO) {
        return Validation.builder().
                validiertVon(validationDTO.getValidiertVon()).
                validStatus(validationDTO.isValidStatus()).
                validationDatum(validationDTO.getValidationDatum()).
                build();
    }

    public static ValidationEntity buildValidationEntityFromValidation(Validation validation) {
        return ValidationEntity.builder().
                id(validation.getId()).
                validiertVon(validation.getValidiertVon()).
                validStatus(validation.isValidStatus()).
                validationDatum(validation.getValidationDatum()).
                build();
    }

    public static ABEZertifikat generateAbeZertifikat() {
        return ABEZertifikat.builder().
                name("abe_test_zertifikat.jpeg").
                type("image/jpeg").
                data(new byte[50]).
                build();
    }

    public static ABEZertifikatDTO generateAbeZertifikatDTO() {
        return ABEZertifikatDTO.builder().
                name("abe_test_zertifikat.jpeg").
                type("image/jpeg").
                size(50L).
                build();
    }

    public static ABEZertifikatEntity generateAbeZertifikatEntity(){
        return ABEZertifikatEntity.builder().
                name("abe_test_zertifikat.jpeg").
                type("image/jpeg").
                data(new byte[50]).
                build();
    }

    public static List<ABEZertifikatDTO> generateAbeZertifikatDTOList() {
        List<ABEZertifikatDTO> abeZertifikatDTOList = new ArrayList<>();
        abeZertifikatDTOList.add(generateAbeZertifikatDTO());
        abeZertifikatDTOList.add(generateAbeZertifikatDTO());
        abeZertifikatDTOList.add(generateAbeZertifikatDTO());
        return abeZertifikatDTOList;
    }

    public static Stream<ABEZertifikat> generateStreamAbeZertifikat() {
        ABEZertifikat abe1 =ABEZertifikat.builder().
                name("abe1_test_zertifikat.jpeg").
                type("image/jpeg").
                data(new byte[50]).
                build();
        ABEZertifikat abe2 = ABEZertifikat.builder().
                name("abe2_test_zertifikat.jpeg").
                type("image/jpeg").
                data(new byte[50]).
                build();

        return Stream.of(abe1, abe2);
    }


}
