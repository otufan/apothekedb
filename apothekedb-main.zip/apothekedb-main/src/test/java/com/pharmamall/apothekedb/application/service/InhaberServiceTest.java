package com.pharmamall.apothekedb.application.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.exception.ConflictException;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.application.port.out.InhaberPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class InhaberServiceTest {

    @Mock
    private InhaberPort inhaberPort;
    @Mock
    private ApothekePort apothekePort;

    @InjectMocks
    private InhaberService inhaberService;

    private Long apothekeId;
    private Long inhaberId;
    private Apotheke apotheke;
    private Inhaber inhaber;
    private InhaberDTO inhaberDTO;
    private List<Inhaber> inhaberList;



    @BeforeEach
    void setUp() {
        apothekeId = 111L;
        inhaberId = 222L;
        apotheke = TestDataGenerator.generateApotheke();
        inhaber = TestDataGenerator.generateInhaber();
        inhaberDTO = TestDataGenerator.generateInhaberDTO();
        inhaberList = TestDataGenerator.geberateInhaberList();
    }

    @Test
    void createInhaberTest() {

        Inhaber inhaber = TestDataGenerator.buildInhaberFromInhaberDTO(inhaberDTO);

        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        when(inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(false);
        when(inhaberPort.write(inhaber)).thenReturn(inhaber);
        inhaber=inhaberPort.write(inhaber);
        apotheke.setInhabers(new ArrayList<>());


        inhaberService.createInhaber(inhaberDTO, apothekeId);
        verify(apothekePort, times(1)).findById(eq(apothekeId));
        verify(inhaberPort, times(1)).existsInhaberBySteuerNummer(eq(inhaber.getSteuerNummer()));
        verify(inhaberPort, times(2)).write(eq(inhaber));
        apotheke.getInhabers().add(inhaber);
        verify(apothekePort, times(1)).write(apotheke);
    }

    @Test
    void createInhaberWithExistingEmailThrowExceptionTest() {

        Inhaber inhaber = TestDataGenerator.buildInhaberFromInhaberDTO(inhaberDTO);

        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        when(inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(true);
        Inhaber inhaberDetails = TestDataGenerator.generateInhaber();
        when(inhaberPort.findBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(inhaberDetails);

        var conflictException = assertThrows(ConflictException.class, ()->inhaberService.createInhaber(inhaberDTO, apothekeId));
        assertEquals("Steuer Nummer ist vom anderen Inhaber besetzt!", conflictException.getMessage());

        verify(apothekePort, times(1)).findById(eq(apothekeId));
        verify(inhaberPort, times(1)).existsInhaberBySteuerNummer(eq(inhaber.getSteuerNummer()));
        verify(inhaberPort, times(1)).findBySteuerNummer(inhaber.getSteuerNummer());


    }

    @Test
    void createInhaberWithExistingEmailTest() {

        Inhaber inhaber = TestDataGenerator.buildInhaberFromInhaberDTO(inhaberDTO);

        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);
        when(inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(true);
        when(inhaberPort.findBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(inhaber);
        apotheke.setInhabers(new ArrayList<>());
        apotheke.getInhabers().add(inhaber);

        inhaberService.createInhaber(inhaberDTO, apothekeId);

        verify(apothekePort, times(1)).findById(eq(apothekeId));
        verify(inhaberPort, times(1)).existsInhaberBySteuerNummer(eq(inhaber.getSteuerNummer()));
        verify(inhaberPort, times(1)).findBySteuerNummer(eq(inhaber.getSteuerNummer()));
        verify(apothekePort, times(1)).write(eq(apotheke));
        verify(inhaberPort, times(1)).write(eq(inhaber));

    }

    @Test
    void findByIdTest() {

        InhaberDTO inhaberDTO = TestDataGenerator.buildInhaberDTOFromInhaber(inhaber);

        when(inhaberPort.findById(inhaberId)).thenReturn(inhaber);
        InhaberDTO result = inhaberService.findById(inhaberId);

        verify(inhaberPort, times(1)).findById(eq(inhaberId));
        assertEquals(inhaberDTO, result);
    }

    @Test
    void updateInhaberTest() {

        when(inhaberPort.findById(inhaberId)).thenReturn(TestDataGenerator.generateInhaber());

        Inhaber inhaber = TestDataGenerator.buildInhaberFromInhaberDTO(inhaberDTO);
        inhaber.setId(inhaberId);

        when(inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(false);

        inhaberService.updateInhaber(inhaberId, inhaberDTO);
        verify(inhaberPort, times(1)).findById(eq(inhaberId));
        verify(inhaberPort, times(1)).existsInhaberBySteuerNummer(inhaber.getSteuerNummer());

        when(inhaberPort.write(inhaber)).thenReturn(inhaber);
        assertEquals(inhaber, inhaberPort.write(inhaber));

    }

    @Test
    void updateInhaberExistingEmailTest() {

        inhaberDTO.setSteuerNummer("1234567");
        when(inhaberPort.findById(inhaberId)).thenReturn(TestDataGenerator.generateInhaber());

        Inhaber inhaber = TestDataGenerator.buildInhaberFromInhaberDTO(inhaberDTO);
        inhaber.setId(inhaberId);

        Inhaber inhaberDetails = TestDataGenerator.generateInhaber();
        inhaberDetails.setSteuerNummer("1234567");


        when(inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(true);
        when(inhaberPort.findBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(inhaberDetails);

        var conflictException = assertThrows(ConflictException.class, ()->inhaberService.updateInhaber(inhaberId, inhaberDTO));
        assertEquals("Steuer Nummer ist vom anderen Inhaber besetzt!", conflictException.getMessage());

        verify(inhaberPort, times(1)).findById(eq(inhaberId));
        verify(inhaberPort, times(1)).existsInhaberBySteuerNummer(eq(inhaber.getSteuerNummer()));
        verify(inhaberPort, times(1)).findBySteuerNummer(eq(inhaber.getSteuerNummer()));

    }

    @Test
    void removeInhaberByIdTest() {
        inhaber.setId(inhaberId);
        apotheke.setId(apothekeId);
        List<Inhaber> list = new ArrayList<>();
        list.add(inhaber);
        apotheke.setInhabers(list);
        when(apothekePort.findById(apothekeId)).thenReturn(apotheke);

        inhaberService.removeInhaberById(apothekeId, inhaberId);

        verify(inhaberPort, times(1)).findById(eq(inhaberId));
        verify(apothekePort, times(1)).findById(eq(apothekeId));
        verify(apothekePort, times(1)).write(eq(apotheke));

    }

    @Test
    void fetchAllInhabersTest() {

        when(inhaberPort.findAll()).thenReturn(inhaberList);

        List<InhaberDTO> result = inhaberService.fetchAllInhabers();

        verify(inhaberPort, times(1)).findAll();
        assertEquals(inhaberList.size(), result.size());

    }
}
