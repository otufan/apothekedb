package com.pharmamall.apothekedb.adapter.storage;

import static org.mockito.Mockito.*;

import com.pharmamall.apothekedb.adapter.storage.entity.InhaberEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.InhaberMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.InhaberRepository;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class InhaberAdapterTest {

    @Mock
    private InhaberRepository repository;

    @Mock
    private InhaberMapper mapper;

    @InjectMocks
    private InhaberAdapter inhaberAdapter;

    private Long inhaberId;
    private Inhaber inhaber;


    @BeforeEach
    void setUp() {

        inhaberId = 222L;
        inhaber = TestDataGenerator.generateInhaber();
    }

    @Test
    void writeTest() {
        inhaberAdapter.write(inhaber);
        verify(repository, times(1)).save(mapper.mapToInhaberEntity(eq(inhaber)));
    }

    @Test
    void findByIdTest() {

        InhaberEntity inhaberEntity = TestDataGenerator.buildInhaberEntityFromInhaber(inhaber);
        inhaberEntity.setId(inhaberId);
        when(repository.findById(inhaberId)).thenReturn(Optional.of(inhaberEntity));
        inhaberAdapter.findById(inhaberId);
        verify(repository, times(1)).findById(eq(inhaberId));
    }

    @Test
    void deleteByIdTest() {
        inhaberAdapter.deleteById(inhaberId);
        verify(repository, times(1)).deleteById(eq(inhaberId));

    }

    @Test
    void findAllTest() {
        inhaberAdapter.findAll();
        verify(repository, times(1)).findAll();

    }

    @Test
    void existsInhaberBySteuerNummerTest() {
        when(repository.existsBySteuerNummer(inhaber.getSteuerNummer())).thenReturn(true);
        inhaberAdapter.existsInhaberBySteuerNummer(inhaber.getSteuerNummer());
        verify(repository, times(1)).existsBySteuerNummer(eq(inhaber.getSteuerNummer()));
        Assertions.assertTrue(repository.existsBySteuerNummer(inhaber.getSteuerNummer()));
    }

    @Test
    void findBySteuerNummerTest() {
        InhaberEntity inhaberEntity = TestDataGenerator.buildInhaberEntityFromInhaber(inhaber);
        inhaberEntity.setId(inhaberId);
        when(repository.findBySteuerNummer(inhaberEntity.getSteuerNummer())).thenReturn(inhaberEntity);
        inhaberAdapter.findBySteuerNummer(inhaberEntity.getSteuerNummer());
        verify(repository, times(1)).findBySteuerNummer(eq(inhaberEntity.getSteuerNummer()));


    }
}
