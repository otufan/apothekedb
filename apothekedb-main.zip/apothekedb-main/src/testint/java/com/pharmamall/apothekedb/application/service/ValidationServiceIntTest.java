package com.pharmamall.apothekedb.application.service;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.application.port.dto.ValidationDTO;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.application.port.out.ValidationPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ValidationServiceIntTest {

    @Autowired
    private ValidationService validationService;

    @Autowired
    private ValidationPort validationPort;

    @Autowired
    private ApothekePort apothekePort;

    private ValidationDTO validationDTO;
    private Validation validation;

    private Apotheke apotheke;


    @BeforeEach
    void setUp()  {
        validationDTO = TestDataGenerator.generateValidationDTO();
        validation = TestDataGenerator.generateValidation();
        apotheke = TestDataGenerator.generateApotheke();
    }

    @Test
    void validateApotheke(){

        if (apothekePort.existsByEmail(apotheke.getEmail())) {
            apotheke = apothekePort.findByEmail(apotheke.getEmail());
            apothekePort.deleteById(apotheke.getId());
        }
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        long restTage = ChronoUnit.DAYS.between(validationDTO.getValidationDatum(), LocalDate.now());
        validationDTO.setValidStatus(restTage <= 180 && validationDTO.isValidStatus());

        validationService.validateApotheke(validationDTO, apotheke.getId());
        validationDTO.setApotheke(apotheke);
        assertEquals(apotheke, validationPort.findValidationByApothekeId(apotheke.getId()).getApotheke());

    }

    @Test
    void removeValidationIntTest(){

        if (apothekePort.existsByEmail(apotheke.getEmail())) {
            apotheke = apothekePort.findByEmail(apotheke.getEmail());
            apothekePort.deleteById(apotheke.getId());
        }
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        validationPort.save(validation, apotheke);
        Long validationId = validationPort.findValidationByApothekeId(apotheke.getId()).getId();
        validationService.removeValidation(validationId);
        var resourceNotFound = assertThrows(ResourceNotFoundException.class, ()->validationPort.findById(validationId));
        assertEquals(String.format("Validation mit id %d ist nicht gefunden", validationId), resourceNotFound.getMessage());

    }
}
