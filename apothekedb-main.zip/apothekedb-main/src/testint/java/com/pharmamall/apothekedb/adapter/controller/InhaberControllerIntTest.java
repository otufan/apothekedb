package com.pharmamall.apothekedb.adapter.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.application.port.out.InhaberPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import javax.ws.rs.core.MediaType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;

@SpringBootTest(classes = ApothekedbApplication.class)
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class InhaberControllerIntTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private InhaberPort inhaberPort;

    @Autowired
    private ApothekePort apothekePort;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void registerInhaberIntTestAndgetInhaberIntTest() throws Exception {

        Apotheke apotheke = TestDataGenerator.generateApotheke();
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        InhaberDTO inhaberDTO = TestDataGenerator.generateInhaberDTO();
        objectMapper.registerModule(new JavaTimeModule());

        Apotheke finalApotheke = apotheke;
        assertDoesNotThrow(() -> {
            mvc.perform(post("/apotheke/"+ finalApotheke.getId()+"/inhaber").
                    contentType(MediaType.APPLICATION_JSON).
                    content(objectMapper.writeValueAsString(inhaberDTO))).andExpect(status().isCreated());
        });

        Long inhaberId = inhaberPort.findBySteuerNummer(inhaberDTO.getSteuerNummer()).getId();

        var requestBuilder = get("/inhaber/{id}", inhaberId);
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);

    }

    @Test
    void getAllInhaberIntTest() throws Exception {

        var requestBuilder = get("/inhaber/all");
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);

    }

    @Test
    void updateInhaberIntTest(){

        Apotheke apotheke = TestDataGenerator.generateApotheke();
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        InhaberDTO inhaberDTO = TestDataGenerator.generateInhaberDTO();
        objectMapper.registerModule(new JavaTimeModule());

        Apotheke finalApotheke = apotheke;
        assertDoesNotThrow(() -> {
            mvc.perform(post("/apotheke/"+ finalApotheke.getId()+"/inhaber").
                    contentType(MediaType.APPLICATION_JSON).
                    content(objectMapper.writeValueAsString(inhaberDTO))).andExpect(status().isCreated());
        });

        Long inhaberId = inhaberPort.findBySteuerNummer(inhaberDTO.getSteuerNummer()).getId();
        InhaberDTO inhaberUpdate = TestDataGenerator.generateInhaberDTO();

        assertDoesNotThrow(() -> {
            mvc.perform(put("/inhaber/"+ inhaberId).
                    contentType(MediaType.APPLICATION_JSON).
                    content(objectMapper.writeValueAsString(inhaberUpdate))).andExpect(status().isOk());
        });

    }
    private MvcResult getResult(ResultActions actions) throws Exception {
        return actions.andExpect(status().isOk()).andReturn();
    }

}
