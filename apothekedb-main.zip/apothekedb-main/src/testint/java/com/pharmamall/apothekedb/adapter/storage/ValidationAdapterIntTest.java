package com.pharmamall.apothekedb.adapter.storage;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.adapter.storage.entity.ValidationEntity;
import com.pharmamall.apothekedb.adapter.storage.repository.ValidationRepository;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ValidationAdapterIntTest {

    @Autowired
    private ValidationAdapter validationAdapter;

    @Autowired
    private ValidationRepository repository;

    @Autowired
    private ApothekeAdapter apothekeAdapter;

    private Validation validation;
    private Apotheke apotheke;

    @BeforeEach
    void setUp()  {

        validation = TestDataGenerator.generateValidation();
        apotheke = TestDataGenerator.generateApotheke();
    }

    @Test
    void saveIntTest(){

        apothekeAdapter.write(apotheke);
        apotheke.setId(apothekeAdapter.findByEmailWithValue(apotheke.getEmail()).get(0).getId());
        Long validationId = repository.save(TestDataGenerator.buildValidationEntityFromValidation(validation)).getId();
        validationAdapter.save(validation, apotheke);
        assertTrue(repository.findById(validationId).isPresent());

    }

    @Test
    @Disabled("Achtung: Alle Daten sind in Testumgebung gelöscht")
    void findAllValidationIntTest(){
        Apotheke apotheke;
        Validation validation;

        repository.deleteAll();
        for (int i = 0; i<5 ; i++) {
            apotheke =TestDataGenerator.generateApotheke();
            validation = TestDataGenerator.generateValidation();
            apothekeAdapter.write(apotheke);
            apotheke.setId(apothekeAdapter.findByEmail(apotheke.getEmail()).getId());
            validationAdapter.save(validation, apotheke);
        }
        assertEquals(validationAdapter.findAllValidation().size(),5);

    }

    @Test
    void findByIsIntTest(){
        ValidationEntity validationDetails = repository.save(TestDataGenerator.buildValidationEntityFromValidation(validation));

        assertEquals(validationAdapter.findById(validationDetails.getId()).getId(), validationDetails.getId());
    }

    @Test
    void deleteByIdIntTest(){

        Long validationId = repository.save(TestDataGenerator.buildValidationEntityFromValidation(validation)).getId();
        validationAdapter.deleteById(validationId);
        assertFalse(repository.findById(validationId).isPresent());

    }

    @Test
    void findValidationByApothekeIdIntTest(){
        apothekeAdapter.write(apotheke);
        apotheke.setId(apothekeAdapter.findByEmail(apotheke.getEmail()).getId());
        validationAdapter.save(validation, apotheke);
        assertEquals(apotheke.getEmail(), validationAdapter.findValidationByApothekeId(apotheke.getId()).getApotheke().getEmail());
    }


}
