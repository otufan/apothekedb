package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.adapter.storage.entity.ApothekeEntity;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ApothekeMapperIntTest {


    @Autowired
    private ApothekeMapper apothekeMapper;
    private Apotheke apotheke;
    private ApothekeEntity apothekeEntity;


    @BeforeEach
    void setUp()  {

        apotheke = TestDataGenerator.generateApotheke();
        apothekeEntity = TestDataGenerator.buildApothekeEntityFromApotheke(apotheke);

    }

    @Test
    void mapToApothekeEntityIntTest(){

        var mapToApothekeEntity = apothekeMapper.mapToApothekeEntity(apotheke);
        var mapToApotheke = apothekeMapper.mapToApotheke(mapToApothekeEntity);
        assertEquals(mapToApotheke, apotheke);

    }

    @Test
    void mapToApothekeIntTest(){

        apothekeEntity.setInhabers(new ArrayList<>());
        var mapToApotheke = apothekeMapper.mapToApotheke(apothekeEntity);
        var mapToApothekeEntity = apothekeMapper.mapToApothekeEntity(mapToApotheke);
        assertEquals(mapToApothekeEntity, apothekeEntity);

    }

    @Test
    void mapToApothekeListTest(){
        List<ApothekeEntity> apothekeEntityList = List.of(apothekeEntity);
        var result = apothekeMapper.mapToApothekeList(apothekeEntityList);
        assertEquals(apothekeEntityList.size(), result.size());
    }

}
