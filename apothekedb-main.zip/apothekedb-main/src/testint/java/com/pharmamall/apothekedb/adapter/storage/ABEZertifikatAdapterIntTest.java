package com.pharmamall.apothekedb.adapter.storage;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ABEZertifikatMapper;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ApothekeMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.ABEZertifikatRepository;
import com.pharmamall.apothekedb.adapter.storage.repository.ApothekeRepository;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ABEZertifikatAdapterIntTest {

    @Autowired
    private ABEZertifikatAdapter abeZertifikatAdapter;

    @Autowired
    private ABEZertifikatMapper abeZertifikatMapper;

    @Autowired
    private ABEZertifikatRepository repository;

    @Autowired
    private ApothekeRepository apothekeRepository;

    @Autowired
    ApothekeMapper apothekeMapper;

    private ABEZertifikat abeZertifikat;
    private Apotheke apotheke;

    @BeforeEach
    void setUp()  {

        abeZertifikat = TestDataGenerator.generateAbeZertifikat();
        apotheke = TestDataGenerator.generateApotheke();
    }

    @Test
    void findByIdIntTest(){

        Long abeZertifikatId = repository.save(abeZertifikatMapper.mapToABEZertifikatEntity(abeZertifikat)).getId();
        abeZertifikat.setId(abeZertifikatId);
        ABEZertifikat abeZertifikatDetails = abeZertifikatAdapter.findById(abeZertifikatId);
        assertEquals(abeZertifikatDetails, abeZertifikat);

    }

    @Test
    void saveIntTest(){
        abeZertifikat = abeZertifikatAdapter.save(abeZertifikat);
        assertTrue(repository.findById(abeZertifikat.getId()).isPresent());

    }

    @Test
    void findAllIntTest(){
        int size = repository.findAll().size();
        assertEquals(abeZertifikatAdapter.findAll().toList().size(), size );

    }

    @Test
    void setApothekeIntSet(){
        apotheke = apothekeMapper.mapToApotheke(
                apothekeRepository.save(apothekeMapper.mapToApothekeEntity(apotheke))
        );
        abeZertifikat = abeZertifikatMapper.mapToABEZertifikat(
                repository.save(abeZertifikatMapper.mapToABEZertifikatEntity(abeZertifikat))
        );
        abeZertifikat.setApotheke(apotheke);
        abeZertifikatAdapter.setApothekeInABEZertifikat(abeZertifikat, apotheke);
        assertEquals(abeZertifikat, abeZertifikatAdapter.findABEZertifikatByApothekeId(apotheke.getId()));
    }
}
