package com.pharmamall.apothekedb.adapter.storage;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.adapter.storage.repository.InhaberRepository;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class InhaberAdapterIntTest {

    @Autowired
    private InhaberAdapter inhaberAdapter;

    @Autowired
    private InhaberRepository repository;

    private Inhaber inhaber;

    @BeforeEach
    void setUp()  {

        inhaber = TestDataGenerator.generateInhaber();
    }

    @Test
    void writeIntTest(){

        if(repository.existsBySteuerNummer(inhaber.getSteuerNummer())){
            Long inhaberId = repository.findBySteuerNummer(inhaber.getSteuerNummer()).getId();
            repository.deleteById(inhaberId);
        }
        inhaberAdapter.write(inhaber);
        assertTrue(repository.existsBySteuerNummer(inhaber.getSteuerNummer()));

    }

    @Test
    void findByIdIntTest(){

        inhaberAdapter.write(inhaber);
        Long inhaberId = repository.findBySteuerNummer(inhaber.getSteuerNummer()).getId();
        assertEquals(inhaberAdapter.findById(inhaberId).getSteuerNummer(), inhaber.getSteuerNummer());

    }

    @Test
    void deleteByIdIntTest(){
        if (!repository.existsBySteuerNummer(inhaber.getSteuerNummer())){
            repository.save(TestDataGenerator.buildInhaberEntityFromInhaber(inhaber));
        }
        Long inhaberId = repository.findBySteuerNummer(inhaber.getSteuerNummer()).getId();
        inhaberAdapter.deleteById(inhaberId);
        assertFalse(repository.findById(inhaberId).isPresent());
    }

    @Test
    void findAllIntTest() {

        assertEquals(repository.findAll().size(), inhaberAdapter.findAll().size());
    }

    @Test
    void existsInhaberBySteuerNummerIntTest(){

        if (!repository.existsBySteuerNummer(inhaber.getSteuerNummer())){
            repository.save(TestDataGenerator.buildInhaberEntityFromInhaber(inhaber));
        }
        assertTrue(inhaberAdapter.existsInhaberBySteuerNummer(inhaber.getSteuerNummer()));

    }

    @Test
    void findBySteuerNummerIntTest(){

        if (!repository.existsBySteuerNummer(inhaber.getSteuerNummer())){
            repository.save(TestDataGenerator.buildInhaberEntityFromInhaber(inhaber));
        }
        String steuerNummer = inhaberAdapter.findBySteuerNummer(inhaber.getSteuerNummer()).getSteuerNummer();

        assertEquals(steuerNummer, inhaber.getSteuerNummer());

    }

}
