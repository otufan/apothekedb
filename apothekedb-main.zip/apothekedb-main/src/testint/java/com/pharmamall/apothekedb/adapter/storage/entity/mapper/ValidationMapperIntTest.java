package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.adapter.storage.entity.ValidationEntity;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ValidationMapperIntTest {

    @Autowired
    private ValidationMapper validationMapper;

    private Validation validation;
    private ValidationEntity validationEntity;

    @BeforeEach
    void setUp() {
        validation = TestDataGenerator.generateValidation();
        validationEntity = TestDataGenerator.buildValidationEntityFromValidation(validation);
    }

    @Test
    void mapToValidationEntityIntTest() {

        var mapToValidationEntity = validationMapper.mapToValidationEntity(validation);
        var mapToValidation = validationMapper.mapToValidation(mapToValidationEntity);
        assertEquals(mapToValidation, validation);

    }

    @Test
    void mapToValidationIntTest() {

        var mapToValidation = validationMapper.mapToValidation(validationEntity);
        var mapToValidationEntity = validationMapper.mapToValidationEntity(mapToValidation);
        assertEquals(mapToValidationEntity, validationEntity);

    }

    @Test
    void mapToValidationListIntTest() {
        List<ValidationEntity> validationEntityList = List.of(validationEntity);
        var result = validationMapper.mapToValidationList(validationEntityList);
        assertEquals(validationEntityList.size(), result.size());
    }

}
