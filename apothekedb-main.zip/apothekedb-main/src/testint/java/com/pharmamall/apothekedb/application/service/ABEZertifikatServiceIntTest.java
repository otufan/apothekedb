package com.pharmamall.apothekedb.application.service;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.application.port.out.ABEZertifikatPort;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ABEZertifikatServiceIntTest {

    @Autowired
    private ABEZertifikatService abeZertifikatService;

    @Autowired
    private ABEZertifikatPort abeZertifikatPort;

    @Autowired
    private ApothekePort apothekePort;

    private MultipartFile zertifikat;
    private ABEZertifikat abeZertifikat;
    private Apotheke apotheke;

    @BeforeEach
    void setUp() throws IOException {

        zertifikat = new MockMultipartFile("test_abe_zertifikat.jpg",
                new FileInputStream(new File("src/testint/resources/test_abe_zertifikat.jpg")));
        abeZertifikat = TestDataGenerator.generateAbeZertifikat();
        apotheke = TestDataGenerator.generateApotheke();
    }

    @Test
    void getZertifikatByIdIntTest() throws IOException {

        if (!apothekePort.existsByEmail(apotheke.getEmail())) {
            apothekePort.write(apotheke);
        }
        apotheke = apothekePort.findByEmail(apotheke.getEmail());

        abeZertifikat = abeZertifikatService.store(zertifikat, apotheke.getId());
        assertTrue(abeZertifikatService.getZertifikatById(abeZertifikat.getId())!= null);


    }

    @Test
    void storeIntTest() throws IOException {

        if (apothekePort.existsByEmail(apotheke.getEmail())) {
            apotheke = apothekePort.findByEmail(apotheke.getEmail());
            apothekePort.deleteById(apotheke.getId());
        }
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        assertNull(abeZertifikatPort.findABEZertifikatByApothekeId(apotheke.getId()));

        abeZertifikat = abeZertifikatService.store(zertifikat, apotheke.getId());
        assertTrue(abeZertifikatService.getZertifikatById(abeZertifikat.getId())!= null);
    }

    @Test
    void fetchAllAbeZertifikatIntTest(){
        int size = abeZertifikatPort.findAll().collect(Collectors.toList()).size();
        assertEquals(size, abeZertifikatService.fetchAllAbeZertifikate().size());
    }




}
