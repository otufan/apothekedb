package com.pharmamall.apothekedb.adapter.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.application.filter.ApothekeFilter;
import com.pharmamall.apothekedb.application.filter.ApothekeFilterParam;
import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.in.InhaberUseCase;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import javax.ws.rs.core.MediaType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;

@SpringBootTest(classes = ApothekedbApplication.class)
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class ApothekeControllerIntTest {

    @Autowired
    private MockMvc mvc;
    @Autowired
    private ApothekePort apothekePort;

    @Autowired
    private InhaberUseCase inhaberUseCase;

    private final ObjectMapper objectMapper = new ObjectMapper();



    @Test
    void registerApothekeIntTest() {
        var apothekeDTO = TestDataGenerator.generateApothekeDTO();
        assertDoesNotThrow(() -> {
            mvc.perform(post("/apotheke").
                    contentType(MediaType.APPLICATION_JSON).
                    content(objectMapper.writeValueAsBytes(apothekeDTO))).andExpect(status().isCreated());
        });
    }

    @Test
    void getApothekeIntTest() throws Exception {
        var apotheke = TestDataGenerator.generateApotheke();
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());

        var requestBuilder = get("/apotheke/{id}", apotheke.getId());
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);
    }

    @Test
    void getAllApothekenIntTest() throws Exception {

        var requestBuilder = get("/apotheke/all");
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);
    }

    @Test
    void deleteApothekeIntTest() throws Exception {
        var apotheke = TestDataGenerator.generateApotheke();
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());

        var requestBuilder = delete("/apotheke/{id}", apotheke.getId());
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);
    }

    @Test
    void updateApothekeIntTest() {
        var apotheke = TestDataGenerator.generateApotheke();
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());

        var apothekeUpdate = TestDataGenerator.generateApothekeDTO();

        Apotheke finalApotheke = apotheke;
        assertDoesNotThrow(() -> {
            mvc.perform(put("/apotheke/"+ finalApotheke.getId()).
                    contentType(MediaType.APPLICATION_JSON).
                    content(objectMapper.writeValueAsBytes(apothekeUpdate))).andExpect(status().isOk());
        });
    }
    @Test
    void deleteInhaberIntTest() throws Exception {

        var apotheke = TestDataGenerator.generateApotheke();
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        var inhaber = TestDataGenerator.generateInhaber();
        inhaber = inhaberUseCase.createInhaber(mapToInhaberDTO(inhaber), apotheke.getId());

        var requestBuilder = delete("/apotheke/{apothekeId}/delete/{inhaberId}", apotheke.getId(), inhaber.getId());
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);
    }

    @Test
    void filterWithValueIntTest() throws Exception {
        ApothekeFilter apothekeFilter = new ApothekeFilter(ApothekeFilterParam.NAME, "tes");

        assertDoesNotThrow(() -> {
            mvc.perform(get("/apotheke/filter").
                    contentType(MediaType.APPLICATION_JSON).
                    content(objectMapper.writeValueAsBytes(apothekeFilter))).andExpect(status().isOk());
        });
    }

    private MvcResult getResult(ResultActions actions) throws Exception {
        return actions.andExpect(status().isOk()).andReturn();
    }
    private InhaberDTO mapToInhaberDTO(Inhaber inhaber) {
        return InhaberDTO.builder().
                vorname(inhaber.getVorname()).
                nachname(inhaber.getNachname()).
                steuerNummer(inhaber.getSteuerNummer()).
                geburtsort(inhaber.getGeburtsort()).
                geburtsdatum(inhaber.getGeburtsdatum()).
                build();
    }

}
