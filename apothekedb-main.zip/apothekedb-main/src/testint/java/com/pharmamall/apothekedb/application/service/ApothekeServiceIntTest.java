package com.pharmamall.apothekedb.application.service;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.application.filter.ApothekeFilter;
import com.pharmamall.apothekedb.application.filter.ApothekeFilterParam;
import com.pharmamall.apothekedb.application.port.dto.ApothekeDTO;
import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ApothekeServiceIntTest {

    @Autowired
    private ApothekeService apothekeService;

    @Autowired
    private ApothekePort apothekePort;

    private ApothekeDTO apothekeDTO;
    private Apotheke apotheke;

    @BeforeEach
    void setUp()  {

        apothekeDTO = TestDataGenerator.generateApothekeDTO();
        apotheke = TestDataGenerator.generateApotheke();
    }

    @Test
    void createApothekeIntTest(){

        if (apothekePort.existsByEmail(apothekeDTO.getEmail())) {
            apotheke = apothekePort.findByEmail(apotheke.getEmail());
            apothekePort.deleteById(apotheke.getId());
        }

        apothekeService.createApotheke(apothekeDTO);
        assertTrue(apothekePort.existsByEmail(apothekeDTO.getEmail()));

    }

    @Test
    void findByIdIntTest(){

        if (apothekePort.existsByEmail(apothekeDTO.getEmail())) {
            apotheke = apothekePort.findByEmail(apotheke.getEmail());
            apothekePort.deleteById(apotheke.getId());
        }

        apothekeService.createApotheke(apothekeDTO);
        apotheke = apothekePort.findByEmail(apothekeDTO.getEmail());
        assertEquals(apothekeDTO.getEmail(), apothekePort.findById(apotheke.getId()).getEmail());
    }

    @Test
    void updateIntTest(){
        apothekeDTO.setInhabers(new ArrayList<>());
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        apothekeService.updateApotheke(apotheke.getId(), apothekeDTO);
        assertEquals(apothekeDTO, mapToApothekeDTO(apothekePort.findById(apotheke.getId())));

    }

    @Test
    void removeByIdIntTest(){

        if (!apothekePort.existsByEmail(apothekeDTO.getEmail())) {
            apothekeService.createApotheke(apothekeDTO);
            apotheke = apothekePort.findByEmail(apothekeDTO.getEmail());
        }

        apothekeService.removeById(apotheke.getId());
        var resourceNotFound = assertThrows(ResourceNotFoundException.class, ()->apothekeService.findById(apotheke.getId()));
        assertEquals(String.format("Apotheke mit id %d ist nicht gefunden", apotheke.getId()), resourceNotFound.getMessage());

    }

    @Test
    void fetchAllApothekenIntTest(){
        int size = apothekePort.findAll().size();
        assertEquals(size, apothekeService.fetchAllApotheken().size());

    }

    @Test
    void fetchAllApothekenWithValueIntTest () {

        ApothekeFilter apothekeFilter = new ApothekeFilter(ApothekeFilterParam.NAME, "test");
        List<ApothekeDTO> resultList = mapToApothekeDTOList(
                apothekePort.findByNameWithValue(apothekeFilter.getValue())
        );
        assertEquals(resultList, apothekeService.fetchAllApothekenWithValue(apothekeFilter));

        apothekeFilter = new ApothekeFilter(ApothekeFilterParam.STRASSE, "test");
        resultList = mapToApothekeDTOList(
                apothekePort.findByStrasseWithValue(apothekeFilter.getValue())
        );
        assertEquals(resultList, apothekeService.fetchAllApothekenWithValue(apothekeFilter));

        apothekeFilter = new ApothekeFilter(ApothekeFilterParam.PLZ, "501");
        resultList = mapToApothekeDTOList(
                apothekePort.findByPlzWithValue(apothekeFilter.getValue())
        );
        assertEquals(resultList, apothekeService.fetchAllApothekenWithValue(apothekeFilter));

        apothekeFilter = new ApothekeFilter(ApothekeFilterParam.ORT, "ko");
        resultList = mapToApothekeDTOList(
                apothekePort.findByOrtWithValue(apothekeFilter.getValue())
        );
        assertEquals(resultList, apothekeService.fetchAllApothekenWithValue(apothekeFilter));

        apothekeFilter = new ApothekeFilter(ApothekeFilterParam.EMAIL, "ada");
        resultList = mapToApothekeDTOList(
                apothekePort.findByEmailWithValue(apothekeFilter.getValue())
        );
        assertEquals(resultList, apothekeService.fetchAllApothekenWithValue(apothekeFilter));

    }



    private ApothekeDTO mapToApothekeDTO (Apotheke apotheke) {
        return ApothekeDTO.builder().
                name(apotheke.getName()).
                strasse(apotheke.getStrasse()).
                plz(apotheke.getPlz()).
                ort(apotheke.getOrt()).
                telefonNummer(apotheke.getTelefonNummer()).
                email(apotheke.getEmail()).
                apothekeGruppe(apotheke.getApothekeGruppe()).
                inhabers(apotheke.getInhabers().stream().map(this::mapToInhaberDTO).collect(Collectors.toList())). //TODO mapping to InhaberDTO
                        build();
    }

    private List<ApothekeDTO> mapToApothekeDTOList(List<Apotheke> apothekeList) {
        return apothekeList.stream().map(this::mapToApothekeDTO).collect(Collectors.toList());
    }

    private InhaberDTO mapToInhaberDTO(Inhaber inhaber) {
        return InhaberDTO.builder().
                vorname(inhaber.getVorname()).
                nachname(inhaber.getNachname()).
                steuerNummer(inhaber.getSteuerNummer()).
                geburtsort(inhaber.getGeburtsort()).
                geburtsdatum(inhaber.getGeburtsdatum()).
                build();
    }


}
