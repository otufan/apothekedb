package com.pharmamall.apothekedb.adapter.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.application.port.out.ABEZertifikatPort;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest(classes = ApothekedbApplication.class)
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class ABEZertifikatControllerIntTest {

    @Autowired
    private MockMvc mvc;
    @Autowired
    private ApothekePort apothekePort;

    @Autowired
    private ABEZertifikatPort abeZertifikatPort;
    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMultipartFile zertifikat;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() throws IOException {
        String filePath = "src/testint/resources/test_abe_zertifikat.jpg";
        byte[] bytes = Files.readAllBytes(Paths.get(filePath));
        zertifikat = new MockMultipartFile("zertifikat",
                "test_abe_zertifikat.jpg",
                "image/JPEG",
                bytes);
    }

    @Test
    void uploadAndDownloadZertifikatIntTest() throws Exception {

        var apotheke = TestDataGenerator.generateApotheke();
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());

        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        MockMvc mockMvc
                = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mockMvc.perform(
                        MockMvcRequestBuilders.multipart("/apotheke/{apothekeId}/zertifikat", apotheke.getId()).
                                file(zertifikat)).
                andExpect(status().isCreated());

        Long abeZertifikatId = abeZertifikatPort.findABEZertifikatByApothekeId(apotheke.getId()).getId();
        var requestBuilder = get("/zertifikat/{id}", abeZertifikatId);
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);
    }


    @Test
    void getAllAbeZertifikateIntTest() throws Exception {

        var requestBuilder = get("/zertifikat/all");
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);

    }
    private MvcResult getResult(ResultActions actions) throws Exception {
        return actions.andExpect(status().isOk()).andReturn();
    }

}
