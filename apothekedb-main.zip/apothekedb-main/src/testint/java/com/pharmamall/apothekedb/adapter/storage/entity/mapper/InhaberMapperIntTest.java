package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.adapter.storage.entity.InhaberEntity;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class InhaberMapperIntTest {

    @Autowired
    private InhaberMapper inhaberMapper;

    private Inhaber inhaber;
    private InhaberEntity inhaberEntity;

    @BeforeEach
    void setUp() {
        inhaber = TestDataGenerator.generateInhaber();
        inhaberEntity = TestDataGenerator.buildInhaberEntityFromInhaber(inhaber);
    }


    @Test
    void mapToInhaberEntityIntTest(){

        var mapToInhaberEntity = inhaberMapper.mapToInhaberEntity(inhaber);
        var mapToInhaber = inhaberMapper.mapToInhaber(mapToInhaberEntity);
        assertEquals(mapToInhaber, inhaber);


    }

    @Test
    void mapToInhaberEntityListIntTest() {

        List<Inhaber> inhaberList = List.of(inhaber);
        var result = inhaberMapper.mapToInhaberEntityList(inhaberList);
        assertEquals(inhaberList.size(), result.size());
    }

    @Test
    void mapToInhaberIntTest() {

        var mapToInhaber = inhaberMapper.mapToInhaber(inhaberEntity);
        var mapToInhaberEntity = inhaberMapper.mapToInhaberEntity(mapToInhaber);
        assertEquals(mapToInhaberEntity, inhaberEntity);

    }

    @Test
    void mapToInhaberListIntTest() {

        List<InhaberEntity> inhaberEntityList = List.of(inhaberEntity);
        var result = inhaberMapper.mapToInhaberList(inhaberEntityList);
        assertEquals(inhaberEntityList.size(), result.size());

    }

}
