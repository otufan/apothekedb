package com.pharmamall.apothekedb.adapter.storage;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.adapter.storage.repository.ApothekeRepository;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ApothekeAdapterIntTest {

    @Autowired
    private ApothekeAdapter apothekeAdapter;

    @Autowired
    private ApothekeRepository repository;
    private Apotheke apotheke;

    @BeforeEach
    void setUp()  {

        apotheke = TestDataGenerator.generateApotheke();
    }

    @Test
    void writeIntTest(){

        apothekeAdapter.write(apotheke);
        assertTrue(repository.existsByEmail(apotheke.getEmail()));


    }

    @Test
    void existsByEmailIntTest() {

        if (!repository.existsByEmail(apotheke.getEmail())) {
            repository.save(TestDataGenerator.buildApothekeEntityFromApotheke(apotheke));
        }
        assertTrue(apothekeAdapter.existsByEmail(apotheke.getEmail()));

    }

    @Test
    void findByIdIntTest() {

        apotheke.setInhabers(List.of(TestDataGenerator.generateInhaber()));
        apothekeAdapter.write(apotheke);
        Long apothekeId = repository.findByEmail(apotheke.getEmail()).getId();
        assertEquals(apothekeAdapter.findById(apothekeId).getEmail(), apotheke.getEmail());

    }

    @Test
    void deleteByIdIntTest(){

        if (!repository.existsByEmail(apotheke.getEmail())) {
            repository.save(TestDataGenerator.buildApothekeEntityFromApotheke(apotheke));

        }
        Long apothekeId = repository.findByEmail(apotheke.getEmail()).getId();
        apothekeAdapter.deleteById(apothekeId);
        assertFalse(repository.findById(apothekeId).isPresent());
    }

    @Test
    @Disabled("Achtung: Alle Daten sind in Testumgebung gelöscht")
    void findAllIntTest() {

        repository.deleteAll();
        for (int i = 0; i<5 ; i++) {
            apothekeAdapter.write(TestDataGenerator.generateApotheke());
        }
        int anzahlDerApotheken = apothekeAdapter.findAll().size();
        assertEquals(5, anzahlDerApotheken);

    }

    @Test
    void findByNameWithValueIntTest(){

        apotheke.setName("Test Apotheke");
        apothekeAdapter.write(apotheke);

        for (Apotheke apotheke : apothekeAdapter.findByNameWithValue("Test Apotheke")) {
            assertTrue(apotheke.getName().contains("Test Apotheke"));
        };
    }

    @Test
    void findByStrasseWithValueIntTest(){

        apotheke.setStrasse("Test Str.");
        apothekeAdapter.write(apotheke);

        for (Apotheke apotheke : apothekeAdapter.findByStrasseWithValue("Test")) {
            assertTrue(apotheke.getStrasse().contains("Test"));
        };
    }

    @Test
    void findByPlzWithValueIntTest(){

        apotheke.setPlz("54000");
        apothekeAdapter.write(apotheke);

        for (Apotheke apotheke : apothekeAdapter.findByPlzWithValue("540")) {
            assertTrue(apotheke.getPlz().contains("540"));
        };
    }

    @Test
    void findByOrtWithValueIntTest(){

        apotheke.setOrt("Bonn");
        apothekeAdapter.write(apotheke);

        for (Apotheke apothekeDetails : apothekeAdapter.findByOrtWithValue("bon")) {
            assertTrue(apothekeDetails.getOrt().contains("Bon"));
        };
    }

    @Test
    void findByEmailWithValueIntTest(){


        for (Apotheke apotheke : apothekeAdapter.findByEmailWithValue("mai")) {
            assertTrue(apotheke.getEmail().contains("mai"));
        };
    }

}
