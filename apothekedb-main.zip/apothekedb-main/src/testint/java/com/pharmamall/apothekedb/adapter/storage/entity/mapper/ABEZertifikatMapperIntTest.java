package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.adapter.storage.entity.ABEZertifikatEntity;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class ABEZertifikatMapperIntTest {

    @Autowired
    private ABEZertifikatMapper abeZertifikatMapper;

    private ABEZertifikatEntity abeZertifikatEntity;

    private ABEZertifikat abeZertifikat;

    @BeforeEach
    void setUp() {
        abeZertifikatEntity = TestDataGenerator.generateAbeZertifikatEntity();
        abeZertifikat = TestDataGenerator.generateAbeZertifikat();

    }

    @Test
    void mapToABEZertifikatIntTest() {

        var mapToABEZertifikat = abeZertifikatMapper.mapToABEZertifikat(abeZertifikatEntity);
        var mapToABEZertifikatEntity = abeZertifikatMapper.mapToABEZertifikatEntity(mapToABEZertifikat);
        assertEquals(abeZertifikatEntity, mapToABEZertifikatEntity);

    }

    @Test
    void mapToABEZertifikatListIntTest() {

        List<ABEZertifikatEntity> abeZertifikatEntityList = List.of(abeZertifikatEntity);
        var result = abeZertifikatMapper.mapToABEZertifikatList(abeZertifikatEntityList);
        assertEquals(abeZertifikatEntityList.size(), result.size());

    }

    @Test
    void mapToABEZertifikatEntityIntTest() {

        var mapToABEZertifikatEntity = abeZertifikatMapper.mapToABEZertifikatEntity(abeZertifikat);
        var mapToABEZertifikat = abeZertifikatMapper.mapToABEZertifikat(mapToABEZertifikatEntity);
        assertEquals(abeZertifikat, mapToABEZertifikat);

    }

}
