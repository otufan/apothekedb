package com.pharmamall.apothekedb.application.service;

import static org.junit.jupiter.api.Assertions.*;

import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.application.port.out.InhaberPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApothekedbApplication.class)
@ExtendWith(MockitoExtension.class)
public class InhaberServiceIntTest {

    @Autowired
    private InhaberService inhaberService;

    @Autowired
    private InhaberPort inhaberPort;

    @Autowired
    private ApothekePort apothekePort;

    private InhaberDTO inhaberDTO;
    private Inhaber inhaber;

    private Apotheke apotheke;

    @BeforeEach
    void setUp()  {
        inhaberDTO = TestDataGenerator.generateInhaberDTO();
        inhaber = TestDataGenerator.generateInhaber();
        apotheke = TestDataGenerator.generateApotheke();
    }

    @Test
    void createInhaberIntTest(){

        if (!apothekePort.existsByEmail(apotheke.getEmail())) {
            apothekePort.write(apotheke);
        }
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        inhaber = inhaberService.createInhaber(inhaberDTO, apotheke.getId());
        assertEquals(inhaberDTO, mapToInhaberDTO(inhaber));

    }

    @Test
    void findByIdIntTest(){

        if (inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())){
            Long inhaberId = inhaberPort.findBySteuerNummer(inhaber.getSteuerNummer()).getId();
            inhaberPort.deleteById(inhaberId);
        }
        inhaber = inhaberPort.write(inhaber);
        assertEquals(inhaber, inhaberPort.findById(inhaber.getId()));

    }

    @Test
    void updateInhaberIntTest(){
        if (inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())){
            inhaber = inhaberPort.findBySteuerNummer(inhaber.getSteuerNummer());
        } else {
            inhaber = inhaberPort.write(inhaber);
        }
        Inhaber inhaberUpdate = inhaberService.updateInhaber(inhaber.getId(), inhaberDTO);
        assertEquals(inhaberDTO, mapToInhaberDTO(inhaberUpdate));
    }

    @Test
    void removeInhaberByIdIntTest(){

        if (!apothekePort.existsByEmail(apotheke.getEmail())) {
            apothekePort.write(apotheke);
        }
        apotheke = apothekePort.findByEmail(apotheke.getEmail());
        inhaber = inhaberService.createInhaber(inhaberDTO, apotheke.getId());
        inhaberService.removeInhaberById(apotheke.getId(), inhaber.getId());
        apotheke = apothekePort.findById(apotheke.getId());
        assertTrue(apotheke.getInhabers().size() == 0);
    }

    @Test
    void fetchAllInhabersIntTest(){

        int size = inhaberPort.findAll().size();
        assertEquals(size, inhaberService.fetchAllInhabers().size());

    }


    private InhaberDTO mapToInhaberDTO(Inhaber inhaber) {
        return InhaberDTO.builder().
                vorname(inhaber.getVorname()).
                nachname(inhaber.getNachname()).
                steuerNummer(inhaber.getSteuerNummer()).
                geburtsort(inhaber.getGeburtsort()).
                geburtsdatum(inhaber.getGeburtsdatum()).
                build();
    }

}
