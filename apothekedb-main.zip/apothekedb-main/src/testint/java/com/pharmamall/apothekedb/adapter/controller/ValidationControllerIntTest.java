package com.pharmamall.apothekedb.adapter.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.pharmamall.apothekedb.ApothekedbApplication;
import com.pharmamall.apothekedb.application.port.dto.ValidationDTO;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.application.port.out.ValidationPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.testdata.TestDataGenerator;
import javax.ws.rs.core.MediaType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;

@SpringBootTest(classes = ApothekedbApplication.class)
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class ValidationControllerIntTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ValidationPort validationPort;

    @Autowired
    private ApothekePort apothekePort;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void validateApothekeAndDeleteValidationIntTest() throws Exception {
        Apotheke apotheke = TestDataGenerator.generateApotheke();
        apothekePort.write(apotheke);
        apotheke = apothekePort.findByEmail(apotheke.getEmail());

        ValidationDTO validationDTO = TestDataGenerator.generateValidationDTO();

        Apotheke finalApotheke = apotheke;
        objectMapper.registerModule(new JavaTimeModule());
        assertDoesNotThrow(() -> {
            mvc.perform(post("/apotheke/{apothekeId}/validation",
                    finalApotheke.getId(), validationDTO).
                    contentType(MediaType.APPLICATION_JSON).
                    content(objectMapper.writeValueAsBytes(validationDTO))).andExpect(status().isCreated());
        });

        Validation validation = validationPort.findValidationByApothekeId(apotheke.getId());

        var requestBuilder = delete("/validation/{id}", validation.getId());
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);

    }

    private MvcResult getResult(ResultActions actions) throws Exception {
        return actions.andExpect(status().isOk()).andReturn();
    }

    @Test
    void getAllValidationIntTest() throws Exception {

        var requestBuilder = get("/validation/all");
        var result = getResult(mvc.perform(requestBuilder));
        var response = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), response);

    }


}
