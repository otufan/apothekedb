package com.pharmamall.apothekedb.domain;

import com.pharmamall.apothekedb.annotations.DomainModel;
import lombok.*;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@DomainModel
public class Validation {

    private Long id;

    private String validiertVon;

    private boolean validStatus;

    private LocalDate validationDatum;

    private Apotheke apotheke;

}
