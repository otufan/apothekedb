package com.pharmamall.apothekedb.domain.enumeration;


public enum ApothekeGruppen {

    GRUPPE_KH, GRUPPE_OA, GROUP_KH_AND_OA
}
