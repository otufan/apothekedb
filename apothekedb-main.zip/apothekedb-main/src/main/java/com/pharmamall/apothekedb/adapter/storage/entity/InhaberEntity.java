package com.pharmamall.apothekedb.adapter.storage.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import lombok.*;

@Entity
@Table(name = "inhaber")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InhaberEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Bitte den Vorname eingeben")
    @Column(nullable = false)
    private String vorname;

    @NotNull(message = "Bitte den Nachname eingeben")
    @Column(nullable = false)
    private String nachname;

    @NotNull(message = "Bitte die Email eingeben")
    @Column(nullable = false, unique = true, name = "steuer_nummer")
    private String steuerNummer;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Europe/Berlin")
    @NotNull(message = "Bitte den Geburtsort eingeben")
    @Column(nullable = false)
    private LocalDate geburtsdatum;

    @NotNull(message = "Bitte das Geburtsdatum eingeben")
    @Column(nullable = false)
    private String geburtsort;

}
