package com.pharmamall.apothekedb.adapter.storage.repository;

import com.pharmamall.apothekedb.adapter.storage.entity.ABEZertifikatEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.ApothekeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface ABEZertifikatRepository extends JpaRepository<ABEZertifikatEntity, Long> {

    @Modifying
    @Query("UPDATE ABEZertifikatEntity a SET a.apotheke = ?2 WHERE a.id = ?1")
    void setApothekeInABEZertifikat(Long id, ApothekeEntity apothekeEntity);

    @Query("SELECT a FROM ABEZertifikatEntity a WHERE a.apotheke.id = ?1")
    ABEZertifikatEntity findABEZertifikatByApothekeId(Long apothekeId);

}
