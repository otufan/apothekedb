package com.pharmamall.apothekedb.adapter.storage.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import lombok.*;


@Entity
@Table(name = "validation")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ValidationEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotNull(message = "Bitte den Name, der Apotheke validiert hat, eingeben")
    @Column(nullable = false, name = "validiert_von")
    private String validiertVon;

    @Column(name = "valid_status")
    private boolean validStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Europe/Berlin")
    @NotNull(message = "Bitte das Datum von Validation eingeben")
    @Column(nullable = false, name = "validation_datum")
    private LocalDate validationDatum;

    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "apotheke_id", referencedColumnName = "id")
    private ApothekeEntity apotheke;

}
