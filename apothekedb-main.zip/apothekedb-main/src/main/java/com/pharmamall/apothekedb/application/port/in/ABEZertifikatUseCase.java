package com.pharmamall.apothekedb.application.port.in;

import com.pharmamall.apothekedb.annotations.Port;
import com.pharmamall.apothekedb.application.port.dto.ABEZertifikatDTO;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Port
public interface ABEZertifikatUseCase {

    ABEZertifikat getZertifikatById(Long id);
    ABEZertifikat store(MultipartFile zertifikat, Long apothekeId) throws IOException;

    List<ABEZertifikatDTO> fetchAllAbeZertifikate();
}
