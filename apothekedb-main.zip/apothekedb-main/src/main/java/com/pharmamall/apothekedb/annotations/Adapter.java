package com.pharmamall.apothekedb.annotations;

public @interface Adapter {

    String value();
}
