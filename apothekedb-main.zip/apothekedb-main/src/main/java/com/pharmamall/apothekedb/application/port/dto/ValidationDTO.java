package com.pharmamall.apothekedb.application.port.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.pharmamall.apothekedb.domain.Apotheke;
import java.time.LocalDate;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class ValidationDTO {

    @NotNull(message = "Bitte den Name, der Apotheke validiert hat, eingeben")
    private String validiertVon;

    private boolean validStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Europe/Berlin")
    @NotNull(message = "Bitte das Datum von Validation eingeben")
    private LocalDate validationDatum;

    private String restTage;

    private Apotheke apotheke;

}
