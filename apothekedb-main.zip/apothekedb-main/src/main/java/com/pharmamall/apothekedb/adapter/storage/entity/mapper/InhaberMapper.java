package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import com.pharmamall.apothekedb.adapter.storage.entity.InhaberEntity;
import com.pharmamall.apothekedb.domain.Inhaber;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

@Component
public class InhaberMapper {

    public InhaberEntity mapToInhaberEntity(Inhaber inhaber) {
        if(inhaber==null) {
            return null;
        }
        return InhaberEntity.builder().
                id(inhaber.getId()).
                vorname(inhaber.getVorname()).
                nachname(inhaber.getNachname()).
                steuerNummer(inhaber.getSteuerNummer()).
                geburtsdatum(inhaber.getGeburtsdatum()).
                geburtsort(inhaber.getGeburtsort()).
                build();
    }
    public List<InhaberEntity> mapToInhaberEntityList(List<Inhaber> inhaberList) {
        return inhaberList.stream().map(this::mapToInhaberEntity).collect(Collectors.toList());
    }

    public Inhaber mapToInhaber(InhaberEntity inhaberEntity) {
        if (inhaberEntity == null ) {
            return null;
        }

        return Inhaber.builder().
                id(inhaberEntity.getId()).
                vorname(inhaberEntity.getVorname()).
                nachname(inhaberEntity.getNachname()).
                steuerNummer(inhaberEntity.getSteuerNummer()).
                geburtsdatum(inhaberEntity.getGeburtsdatum()).
                geburtsort(inhaberEntity.getGeburtsort()).
                build();
    }

    public List<Inhaber> mapToInhaberList(List<InhaberEntity> inhaberEntityList) {
        return inhaberEntityList.stream().map(this::mapToInhaber).collect(Collectors.toList());
    }

}
