package com.pharmamall.apothekedb.adapter.storage.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import lombok.*;

import javax.persistence.*;
@Entity
@Table(name = "abe_zertifikat")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ABEZertifikatEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String type;
    @JsonIgnore
    @Lob
    private byte[] data;

    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "pharmacy_id", referencedColumnName = "id")
    private ApothekeEntity apotheke;
}
