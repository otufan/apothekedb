package com.pharmamall.apothekedb.adapter.storage.repository;

import com.pharmamall.apothekedb.adapter.storage.entity.ApothekeEntity;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface ApothekeRepository extends JpaRepository<ApothekeEntity, Long> {

    boolean existsByEmail(String email) throws ResourceNotFoundException;

    @Query("SELECT a FROM ApothekeEntity a WHERE a.email = ?1")
    ApothekeEntity findByEmail(String email);

    @Query("SELECT a FROM ApothekeEntity a WHERE a.name LIKE %?1%")
    List<ApothekeEntity> findByNameWithValue(String value);

    @Query("SELECT a FROM ApothekeEntity a WHERE a.strasse LIKE %?1% ")
    List<ApothekeEntity> findByStrasseWithValue(String value);

    @Query("SELECT a FROM ApothekeEntity a WHERE a.plz LIKE %?1% ")
    List<ApothekeEntity> findByPlzWithValue(String value);

    @Query("SELECT a FROM ApothekeEntity a WHERE a.ort LIKE %?1% ")
    List<ApothekeEntity> findByOrtWithValue(String value);

    @Query("SELECT a FROM ApothekeEntity a WHERE a.email LIKE %?1% ")
    List<ApothekeEntity> findByEmailWithValue(String value);

}
