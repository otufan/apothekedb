package com.pharmamall.apothekedb.adapter.storage;

import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ABEZertifikatMapper;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ApothekeMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.ABEZertifikatRepository;
import com.pharmamall.apothekedb.annotations.Adapter;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import com.pharmamall.apothekedb.application.port.out.ABEZertifikatPort;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.domain.Apotheke;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.stream.Stream;

@AllArgsConstructor
@Component
@Adapter("persistence")
public class ABEZertifikatAdapter implements ABEZertifikatPort {

    private final ABEZertifikatRepository abeZertifikatRepository;
    private final ABEZertifikatMapper mapper;
    private final ApothekeMapper apothekeMapper;

    @Override
    public ABEZertifikat findById(Long id) {

        return mapper.mapToABEZertifikat(abeZertifikatRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException(String.format("ABE Zertifikat mit id %d ist nicht gefunden", id))));
    }

    @Override
    public ABEZertifikat save(ABEZertifikat abeZertifikat) {

        return mapper.mapToABEZertifikat(abeZertifikatRepository.save(mapper.mapToABEZertifikatEntity(abeZertifikat)));
    }

    @Override
    public Stream<ABEZertifikat> findAll() {

        return mapper.mapToABEZertifikatList(abeZertifikatRepository.findAll()).stream();
    }

    @Override
    public void setApothekeInABEZertifikat(ABEZertifikat abeZertifikat, Apotheke apotheke) {

        abeZertifikatRepository.setApothekeInABEZertifikat(abeZertifikat.getId(), apothekeMapper.mapToApothekeEntity(apotheke));

    }

    @Override
    public ABEZertifikat findABEZertifikatByApothekeId(Long apothekeId) {
        return mapper.mapToABEZertifikat(abeZertifikatRepository.findABEZertifikatByApothekeId(apothekeId));
    }

}
