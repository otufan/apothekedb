package com.pharmamall.apothekedb.application.port.in;

import com.pharmamall.apothekedb.annotations.Port;
import com.pharmamall.apothekedb.application.port.dto.ValidationDTO;
import java.util.List;

@Port
public interface ValidationUseCase {

    void validateApotheke(ValidationDTO validationDTO, Long apothekeId);

    List<ValidationDTO> fetchAllValidation();

    void removeValidation(Long id);
}
