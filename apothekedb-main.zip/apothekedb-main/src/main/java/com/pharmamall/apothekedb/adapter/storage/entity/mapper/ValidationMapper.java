package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import com.pharmamall.apothekedb.adapter.storage.entity.ValidationEntity;
import com.pharmamall.apothekedb.domain.Validation;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

@Component
public class ValidationMapper {

    private ApothekeMapper mapper = new ApothekeMapper();

    public ValidationEntity mapToValidationEntity(Validation validation) {
        if (validation == null) {
            return null;
        }
        return ValidationEntity.builder().
                id(validation.getId()).
                validiertVon(validation.getValidiertVon()).
                validStatus(validation.isValidStatus()).
                validationDatum(validation.getValidationDatum()).
                apotheke(mapper.mapToApothekeEntity(validation.getApotheke())).
                build();
    }

    public Validation mapToValidation(ValidationEntity validationEntity) {
        if(validationEntity == null) {
            return null;
        }

        return Validation.builder().
                id(validationEntity.getId()).
                validiertVon(validationEntity.getValidiertVon()).
                validStatus(validationEntity.isValidStatus()).
                validationDatum(validationEntity.getValidationDatum()).
                apotheke(mapper.mapToApotheke(validationEntity.getApotheke())).
                build();
    }

    public List<Validation> mapToValidationList(List<ValidationEntity> validationEntityList) {
        return validationEntityList.stream().map(this::mapToValidation).collect(Collectors.toList());
    }

}
