package com.pharmamall.apothekedb.annotations;

public @interface Port {
}
