package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import com.pharmamall.apothekedb.adapter.storage.entity.ApothekeEntity;
import com.pharmamall.apothekedb.domain.Apotheke;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

@Component
public class ApothekeMapper {

    private InhaberMapper mapper = new InhaberMapper();

    public ApothekeEntity mapToApothekeEntity(Apotheke apotheke) {
        if (apotheke == null) {
            return null;
        }
        return ApothekeEntity.builder().
                id(apotheke.getId()).
                name(apotheke.getName()).
                strasse(apotheke.getStrasse()).
                plz(apotheke.getPlz()).
                ort(apotheke.getOrt()).
                telefonNummer(apotheke.getTelefonNummer()).
                email(apotheke.getEmail()).
                apothekeGruppe(apotheke.getApothekeGruppe()).
                inhabers(mapper.mapToInhaberEntityList(apotheke.getInhabers()!=null?apotheke.getInhabers():new ArrayList<>())).
                build();
    }

    public Apotheke mapToApotheke(ApothekeEntity apothekeEntity) {
        if (apothekeEntity == null ) {
            return null;
        }

        return Apotheke.builder().
                id(apothekeEntity.getId()).
                name(apothekeEntity.getName()).
                strasse(apothekeEntity.getStrasse()).
                plz(apothekeEntity.getPlz()).
                ort(apothekeEntity.getOrt()).
                telefonNummer(apothekeEntity.getTelefonNummer()).
                email(apothekeEntity.getEmail()).
                apothekeGruppe(apothekeEntity.getApothekeGruppe()).
                inhabers(mapper.mapToInhaberList(apothekeEntity.getInhabers()!=null?apothekeEntity.getInhabers():new ArrayList<>())).
                build();
    }

    public List<Apotheke> mapToApothekeList(List<ApothekeEntity> apothekeEntityList) {
        return apothekeEntityList.stream().map(this::mapToApotheke).collect(Collectors.toList());
    }

}
