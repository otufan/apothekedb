package com.pharmamall.apothekedb.adapter.storage.repository;

import com.pharmamall.apothekedb.adapter.storage.entity.ApothekeEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.ValidationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface ValidationRepository extends JpaRepository<ValidationEntity, Long> {

    @Modifying
    @Query("UPDATE ValidationEntity v SET v.apotheke = ?2 WHERE v.id = ?1")
    void setApotheke(Long id, ApothekeEntity apothekeEntity);

    @Query("SELECT v FROM ValidationEntity v WHERE v.apotheke.id = ?1")
    ValidationEntity findValidationByApothekeId(Long apothekeId);
}
