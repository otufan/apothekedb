package com.pharmamall.apothekedb.application.service;

import com.pharmamall.apothekedb.annotations.ApplicationService;
import com.pharmamall.apothekedb.application.port.dto.ApothekeDTO;
import com.pharmamall.apothekedb.application.filter.ApothekeFilter;
import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.in.ApothekeUseCase;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.application.port.exception.BadRequestException;
import com.pharmamall.apothekedb.application.port.exception.ConflictException;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import com.pharmamall.apothekedb.domain.Inhaber;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@ApplicationService
@AllArgsConstructor
public class ApothekeService implements ApothekeUseCase {

    private final ApothekePort apothekePort;
    @Override
    public void createApotheke(ApothekeDTO apothekeDTO) throws BadRequestException {

        if (apothekePort.existsByEmail(apothekeDTO.getEmail())) {
            throw new ConflictException("E-Mail ist bereits vorhanden");
        }
            Apotheke apotheke = Apotheke.builder().
                    name(apothekeDTO.getName()).
                    strasse(apothekeDTO.getStrasse()).
                    plz(apothekeDTO.getPlz()).
                    ort(apothekeDTO.getOrt()).
                    telefonNummer(apothekeDTO.getTelefonNummer()).
                    email(apothekeDTO.getEmail()).
                    apothekeGruppe(apothekeDTO.getApothekeGruppe()).
                    build();
            apothekePort.write(apotheke);

    }

    @Override
    public ApothekeDTO findById(Long id) throws ResourceNotFoundException {

        Apotheke apotheke = apothekePort.findById(id);

        return ApothekeDTO.builder().
                name(apotheke.getName()).
                strasse(apotheke.getStrasse()).
                plz(apotheke.getPlz()).
                ort(apotheke.getOrt()).
                telefonNummer(apotheke.getTelefonNummer()).
                email(apotheke.getEmail()).
                apothekeGruppe(apotheke.getApothekeGruppe()).
                inhabers(apotheke.getInhabers().stream().map(this::mapToInhaberDTO).collect(Collectors.toList())).
                build();

    }

    @Override
    public void updateApotheke(Long id, ApothekeDTO apothekeDTO) throws BadRequestException {

        boolean emailExists = apothekePort.existsByEmail(apothekeDTO.getEmail());
        Apotheke apothekeDetails = apothekePort.findById(id);

        if (emailExists && !apothekeDTO.getEmail().equals(apothekeDetails.getEmail())) {
            throw new ConflictException("E-Mail ist bereits vorhanden");
        }

        Apotheke apotheke = Apotheke.builder().
                id(id).
                name(apothekeDTO.getName()).
                strasse(apothekeDTO.getStrasse()).
                plz(apothekeDTO.getPlz()).
                ort(apothekeDTO.getOrt()).
                telefonNummer(apothekeDTO.getTelefonNummer()).
                email(apothekeDTO.getEmail()).
                apothekeGruppe(apothekeDTO.getApothekeGruppe()).
                inhabers(apothekeDetails.getInhabers()).
                build();

        apothekePort.write(apotheke);
    }

    @Override
    public void removeById(Long id) throws ResourceNotFoundException {

        if (apothekePort.findById(id) != null) {

            apothekePort.deleteById(id);
        }
    }

    @Override
    public List<ApothekeDTO> fetchAllApotheken() {

        List<Apotheke> apothekeList = apothekePort.findAll();
        List<ApothekeDTO> apothekeDTOList = new ArrayList<>();
        ApothekeDTO apothekeDTO;
        for (Apotheke apotheke : apothekeList) {

            apothekeDTO = ApothekeDTO.builder().
                    name(apotheke.getName()).
                    strasse(apotheke.getStrasse()).
                    plz(apotheke.getPlz()).
                    ort(apotheke.getOrt()).
                    telefonNummer(apotheke.getTelefonNummer()).
                    email(apotheke.getEmail()).
                    apothekeGruppe(apotheke.getApothekeGruppe()).
                    inhabers(apotheke.getInhabers().stream().map(this::mapToInhaberDTO).collect(Collectors.toList())).
                    build();

            apothekeDTOList.add(apothekeDTO);
        }
        return apothekeDTOList;
    }

    @Override
    public List<ApothekeDTO> fetchAllApothekenWithValue(ApothekeFilter apothekeFilter) {

        List<Apotheke> apothekeList = null;

        switch (apothekeFilter.getKey()) {
            case NAME -> apothekeList = apothekePort.findByNameWithValue(apothekeFilter.getValue());
            case STRASSE -> apothekeList = apothekePort.findByStrasseWithValue(apothekeFilter.getValue());
            case PLZ -> apothekeList = apothekePort.findByPlzWithValue(apothekeFilter.getValue());
            case ORT -> apothekeList = apothekePort.findByOrtWithValue(apothekeFilter.getValue());
            case EMAIL -> apothekeList = apothekePort.findByEmailWithValue(apothekeFilter.getValue());
            default -> {
            }
        }
        assert apothekeList != null;
        return apothekeList.stream().map(apotheke->
                ApothekeDTO.builder().
                name(apotheke.getName()).
                strasse(apotheke.getStrasse()).
                plz(apotheke.getPlz()).
                ort(apotheke.getOrt()).
                telefonNummer(apotheke.getTelefonNummer()).
                email(apotheke.getEmail()).
                apothekeGruppe(apotheke.getApothekeGruppe()).
                inhabers(apotheke.getInhabers().stream().map(this::mapToInhaberDTO).collect(Collectors.toList())). //TODO mapping to InhaberDTO
                build()
                ).collect(Collectors.toList());
    }

    private InhaberDTO mapToInhaberDTO(Inhaber inhaber) {
        return InhaberDTO.builder().
                vorname(inhaber.getVorname()).
                nachname(inhaber.getNachname()).
                steuerNummer(inhaber.getSteuerNummer()).
                geburtsort(inhaber.getGeburtsort()).
                geburtsdatum(inhaber.getGeburtsdatum()).
                build();
    }
}
