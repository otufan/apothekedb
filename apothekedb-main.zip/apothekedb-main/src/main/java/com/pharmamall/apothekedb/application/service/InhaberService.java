package com.pharmamall.apothekedb.application.service;

import com.pharmamall.apothekedb.annotations.ApplicationService;
import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.exception.BadRequestException;
import com.pharmamall.apothekedb.application.port.exception.ConflictException;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import com.pharmamall.apothekedb.application.port.in.InhaberUseCase;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.application.port.out.InhaberPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Inhaber;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@ApplicationService
@AllArgsConstructor
public class InhaberService implements InhaberUseCase {

    private final InhaberPort inhaberPort;
    private final ApothekePort apothekePort;

    @Override
    public Inhaber createInhaber(InhaberDTO inhaberDTO, Long apothekeId) throws BadRequestException {

        Apotheke apotheke = apothekePort.findById(apothekeId);
        Inhaber inhaber = Inhaber.builder().vorname(inhaberDTO.getVorname()).nachname(inhaberDTO.getNachname())
                .steuerNummer(inhaberDTO.getSteuerNummer()).geburtsdatum(inhaberDTO.getGeburtsdatum())
                .geburtsort(inhaberDTO.getGeburtsort()).build();

        if (inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())) {
            Inhaber inhaberDetails = inhaberPort.findBySteuerNummer(inhaber.getSteuerNummer());
            if (!(inhaberDetails.getVorname().equals(inhaber.getVorname()) && inhaberDetails.getNachname().equals(inhaber.getNachname()) && inhaberDetails.getGeburtsdatum().equals(inhaber.getGeburtsdatum()) && inhaberDetails.getGeburtsort().equals(inhaber.getGeburtsort()))) {
                throw new ConflictException("Steuer Nummer ist vom anderen Inhaber besetzt!");
            }
            apotheke.getInhabers().add(inhaberDetails);
            apothekePort.write(apotheke);
            return inhaberPort.write(inhaberDetails);
        } else {
            inhaber = inhaberPort.write(inhaber);
            apotheke.getInhabers().add(inhaber);
        }
        apothekePort.write(apotheke);
        return inhaber;
    }

    @Override
    public InhaberDTO findById(Long id) throws ResourceNotFoundException {

        Inhaber inhaber = inhaberPort.findById(id);

        return InhaberDTO.builder().vorname(inhaber.getVorname()).nachname(inhaber.getNachname())
                .geburtsdatum(inhaber.getGeburtsdatum()).geburtsort(inhaber.getGeburtsort()).steuerNummer(inhaber.getSteuerNummer())
                .build();
    }

    @Override
    public Inhaber updateInhaber(Long id, InhaberDTO inhaberDTO) throws BadRequestException {

        inhaberPort.findById(id);

        Inhaber inhaber = Inhaber.builder().id(id).vorname(inhaberDTO.getVorname()).nachname(inhaberDTO.getNachname())
                .steuerNummer(inhaberDTO.getSteuerNummer()).geburtsdatum(inhaberDTO.getGeburtsdatum())
                .geburtsort(inhaberDTO.getGeburtsort()).build();
        if (inhaberPort.existsInhaberBySteuerNummer(inhaber.getSteuerNummer())) {
            Inhaber inhaberDetails = inhaberPort.findBySteuerNummer(inhaber.getSteuerNummer());
            if (!(inhaberDetails.getVorname().equals(inhaber.getVorname()) && inhaberDetails.getNachname().equals(inhaber.getNachname()) && inhaberDetails.getGeburtsdatum().equals(inhaber.getGeburtsdatum()) && inhaberDetails.getGeburtsort().equals(inhaber.getGeburtsort()))) {
                throw new ConflictException("Steuer Nummer ist vom anderen Inhaber besetzt!");
            }
        }

        return inhaberPort.write(inhaber);
    }

    @Override
    public void removeInhaberById(Long apothekeId, Long inhaberId) throws ResourceNotFoundException {

        inhaberPort.findById(inhaberId);
        Apotheke apotheke = apothekePort.findById(apothekeId);
        apotheke.getInhabers().removeIf(inhaberDetail -> inhaberDetail.getId().equals(inhaberId));

        apothekePort.write(apotheke);
    }

    @Override
    public List<InhaberDTO> fetchAllInhabers() {

        List<Inhaber> inhaberList = inhaberPort.findAll();

        return inhaberList.stream()
                .map(inhaber -> InhaberDTO.builder().
                        vorname(inhaber.getVorname()).
                        nachname(inhaber.getNachname()).
                        steuerNummer(inhaber.getSteuerNummer()).
                        geburtsdatum(inhaber.getGeburtsdatum()).
                        geburtsort(inhaber.getGeburtsort()).
                        build()).
                collect(Collectors.toList());
    }

}
