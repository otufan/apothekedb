package com.pharmamall.apothekedb.application.service;

import com.pharmamall.apothekedb.annotations.ApplicationService;
import com.pharmamall.apothekedb.application.port.dto.ValidationDTO;
import com.pharmamall.apothekedb.application.port.in.ValidationUseCase;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.application.port.out.ValidationPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Validation;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@ApplicationService
@AllArgsConstructor
public class ValidationService implements ValidationUseCase {

    private final ValidationPort validationPort;
    private final ApothekePort apothekePort;

    @Override
    public void validateApotheke(ValidationDTO validationDTO, Long apothekeId) {

        Apotheke apotheke = apothekePort.findById(apothekeId);
        long restTage = ChronoUnit.DAYS.between(validationDTO.getValidationDatum(), LocalDate.now());
        validationDTO.setValidStatus(restTage <= 180 && validationDTO.isValidStatus());
        if (validationPort.findValidationByApothekeId(apothekeId) == null) {
            Validation validation = Validation.builder().
                    validiertVon(validationDTO.getValidiertVon()).
                    validStatus(validationDTO.isValidStatus()).
                    validationDatum(validationDTO.getValidationDatum()).
                    build();
            validationPort.save(validation, apotheke);

        } else {
            Validation validation = validationPort.findValidationByApothekeId(apothekeId);
            validation.setValidiertVon(validationDTO.getValidiertVon());
            validation.setValidStatus(validationDTO.isValidStatus());
            validation.setValidationDatum(validationDTO.getValidationDatum());
            validationPort.save(validation, apotheke);
        }

    }
    @Override
    public List<ValidationDTO> fetchAllValidation() {

        List<Validation> validationList = validationPort.findAllValidation();
        return validationList.stream().map(this::mapToValidationDTO).collect(Collectors.toList());

    }

    @Override
    public void removeValidation(Long id) {

        validationPort.findById(id);
        validationPort.deleteById(id);

    }
    private ValidationDTO mapToValidationDTO(Validation validation) {
        return ValidationDTO.builder().
                validiertVon(validation.getValidiertVon()).
                validStatus(validation.isValidStatus()).
                validationDatum(validation.getValidationDatum()).
                apotheke(validation.getApotheke()).
                restTage(String.valueOf(180 - ChronoUnit.DAYS.between(validation.getValidationDatum(), LocalDate.now())>0?
                        (180 - ChronoUnit.DAYS.between(validation.getValidationDatum(), LocalDate.now())):0)).
                build();
    }

}
