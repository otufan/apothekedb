package com.pharmamall.apothekedb.application.port.in;

import com.pharmamall.apothekedb.annotations.Port;
import com.pharmamall.apothekedb.application.port.dto.ApothekeDTO;
import com.pharmamall.apothekedb.application.filter.ApothekeFilter;

import java.util.List;

@Port
public interface ApothekeUseCase {

    void createApotheke(ApothekeDTO apothekeDTO);

    ApothekeDTO findById(Long id);

    void updateApotheke(Long id, ApothekeDTO apothekeDTO);

    void removeById(Long id);

    List<ApothekeDTO> fetchAllApotheken();

    List<ApothekeDTO> fetchAllApothekenWithValue(ApothekeFilter apothekeFilter);
}
