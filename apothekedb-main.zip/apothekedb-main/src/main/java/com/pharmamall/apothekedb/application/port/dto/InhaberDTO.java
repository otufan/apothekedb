package com.pharmamall.apothekedb.application.port.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@Builder
public class InhaberDTO {
    @NotNull(message = "Bitte den Vorname eingeben")
    private String vorname;

    @NotNull(message = "Bitte den Nachname eingeben")
    private String nachname;


    @NotNull(message = "Bitte die Email eingeben")
    private String steuerNummer;

    @NotNull(message = "Bitte den Geburtsort eingeben")
    private LocalDate geburtsdatum;

    @NotNull(message = "Bitte das Geburtsdatum eingeben")
    private String geburtsort;

}
