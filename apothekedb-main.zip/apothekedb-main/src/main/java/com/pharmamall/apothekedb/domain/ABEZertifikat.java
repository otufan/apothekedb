package com.pharmamall.apothekedb.domain;

import com.pharmamall.apothekedb.annotations.DomainModel;
import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DomainModel
public class ABEZertifikat {

    private Long id;

    private String name;
    private String type;

    private byte[] data;

    private Apotheke apotheke;

}
