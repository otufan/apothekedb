package com.pharmamall.apothekedb.adapter.storage.entity.mapper;

import com.pharmamall.apothekedb.adapter.storage.entity.ABEZertifikatEntity;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

@Component
public class ABEZertifikatMapper {

    private ApothekeMapper mapper = new ApothekeMapper();

    public ABEZertifikat mapToABEZertifikat(ABEZertifikatEntity abeZertifikatEntity) {
        if (abeZertifikatEntity == null) {
            return null;
        }
        return ABEZertifikat.builder().
                id(abeZertifikatEntity.getId()).
                name(abeZertifikatEntity.getName()).
                type(abeZertifikatEntity.getType()).
                data(abeZertifikatEntity.getData()).
                apotheke(mapper.mapToApotheke(abeZertifikatEntity.getApotheke())).
                build();
    }
    public List<ABEZertifikat> mapToABEZertifikatList (List<ABEZertifikatEntity> abeZertifikatEntityList) {
        return abeZertifikatEntityList.stream().map(this::mapToABEZertifikat).collect(Collectors.toList());
    }

    public ABEZertifikatEntity mapToABEZertifikatEntity(ABEZertifikat abeZertifikat) {
        if (abeZertifikat == null) {
            return null;
        }
        return ABEZertifikatEntity.builder().
                id(abeZertifikat.getId()).
                name(abeZertifikat.getName()).
                type(abeZertifikat.getType()).
                data(abeZertifikat.getData()).
                apotheke(mapper.mapToApothekeEntity(abeZertifikat.getApotheke())).
                build();
    }
}
