package com.pharmamall.apothekedb.adapter.storage.repository;


import com.pharmamall.apothekedb.adapter.storage.entity.InhaberEntity;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface InhaberRepository extends JpaRepository<InhaberEntity, Long> {

    boolean existsBySteuerNummer(String steuerNummer) throws ResourceNotFoundException;

    InhaberEntity findBySteuerNummer(String email);


}
