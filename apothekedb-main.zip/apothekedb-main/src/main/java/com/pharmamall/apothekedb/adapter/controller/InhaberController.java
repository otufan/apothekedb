package com.pharmamall.apothekedb.adapter.controller;


import com.pharmamall.apothekedb.application.port.dto.InhaberDTO;
import com.pharmamall.apothekedb.application.port.in.InhaberUseCase;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@Produces(MediaType.APPLICATION_JSON)
@RequestMapping("/")
public class InhaberController {

    private final InhaberUseCase inhaberUseCase;

    @PostMapping("/apotheke/{apothekeId}/inhaber")
    public ResponseEntity<Map<String, Boolean>> registerInhaber(@Valid @RequestBody InhaberDTO inhaberDTO, @PathVariable Long apothekeId) {

        inhaberUseCase.createInhaber(inhaberDTO, apothekeId);
        Map<String, Boolean> map = new HashMap<>();
        map.put("Inhaber ist erfolgreich erstellt!", true);
        return new ResponseEntity<>(map, HttpStatus.CREATED);
    }
    @GetMapping("/inhaber/{id}")
    public ResponseEntity<InhaberDTO> getInhaber(@PathVariable Long id) {
        InhaberDTO inhaberDTO = inhaberUseCase.findById(id);
        return new ResponseEntity<>(inhaberDTO, HttpStatus.OK);
    }

    @GetMapping("/inhaber/all")
    public ResponseEntity<List<InhaberDTO>> getAllInhabers() {
        List<InhaberDTO> inhaberDTOList = inhaberUseCase.fetchAllInhabers();
        return new ResponseEntity<>(inhaberDTOList, HttpStatus.OK);
    }

    @PutMapping("/inhaber/{id}")
    public ResponseEntity<Map<String, Boolean>> updateInhaber(@PathVariable Long id, @Valid @RequestBody InhaberDTO inhaberDTO) {

        inhaberUseCase.updateInhaber(id, inhaberDTO);
        Map<String, Boolean> map = new HashMap<>();
        map.put("erfolgreich", true);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }


}
