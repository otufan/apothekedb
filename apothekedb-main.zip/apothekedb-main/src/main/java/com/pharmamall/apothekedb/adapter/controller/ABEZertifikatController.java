package com.pharmamall.apothekedb.adapter.controller;

import com.pharmamall.apothekedb.application.port.dto.ABEZertifikatDTO;
import com.pharmamall.apothekedb.application.port.in.ABEZertifikatUseCase;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@CrossOrigin("http://localhost:8081")
@RequestMapping("/")
public class ABEZertifikatController {

    private final ABEZertifikatUseCase abeZertifikatUseCase;

    @PostMapping("apotheke/{apothekeId}/zertifikat")
    public ResponseEntity<Map<String, String>> uploadAbeZertifikat(@PathVariable Long apothekeId, @RequestParam("zertifikat") MultipartFile zertifikat){

        try {
            ABEZertifikat abeZertifikat = abeZertifikatUseCase.store(zertifikat, apothekeId);
            Map<String, String> map = new HashMap<>();
            map.put("imageId", ""+abeZertifikat.getId());

            return ResponseEntity.status(HttpStatus.CREATED).body(map);

        } catch (IOException e) {

            Map<String, String> map = new HashMap<>();
            map.put("message", "konnte die Datei nicht hochladen: " + zertifikat.getOriginalFilename() + "!");

            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(map);
        }
    }

    @GetMapping("zertifikat/{id}")
    public ResponseEntity<byte[]> downloadAbeZertifikat(@PathVariable Long id) {

        ABEZertifikat abeZertifikat = abeZertifikatUseCase.getZertifikatById(id);
        return ResponseEntity.ok().
                header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + abeZertifikat.getName() + "").
                body(abeZertifikat.getData());
    }

    @GetMapping("zertifikat/all")
    public ResponseEntity<List<ABEZertifikatDTO>> getAllAbeZertifikat() {

        List<ABEZertifikatDTO> abeZertifikatDTOList = abeZertifikatUseCase.fetchAllAbeZertifikate();
        return ResponseEntity.status(HttpStatus.OK).body(abeZertifikatDTOList);

    }

    @GetMapping("zertifikat/{id}/display")
    public ResponseEntity<byte []> displayAbeZertifikat(@PathVariable Long id) {
        ABEZertifikat abeZertifikat = abeZertifikatUseCase.getZertifikatById(id);
        final HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.IMAGE_PNG);
        return new ResponseEntity<>(abeZertifikat.getData(), headers, HttpStatus.CREATED);
    }

}
