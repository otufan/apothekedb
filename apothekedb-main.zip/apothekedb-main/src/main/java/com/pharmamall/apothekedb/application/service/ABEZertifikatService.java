package com.pharmamall.apothekedb.application.service;

import com.pharmamall.apothekedb.annotations.ApplicationService;
import com.pharmamall.apothekedb.application.port.dto.ABEZertifikatDTO;
import com.pharmamall.apothekedb.application.port.in.ABEZertifikatUseCase;
import com.pharmamall.apothekedb.application.port.out.ABEZertifikatPort;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.domain.ABEZertifikat;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@Service
@ApplicationService
@AllArgsConstructor
public class ABEZertifikatService implements ABEZertifikatUseCase {

    private final ABEZertifikatPort abeZertifikatPort;
    private final ApothekePort apothekePort;

    @Override
    public ABEZertifikat getZertifikatById(Long id) throws ResourceNotFoundException {
        return abeZertifikatPort.findById(id);
    }

    @Override
    public ABEZertifikat store(MultipartFile zertifikat, Long apothekeId) throws IOException {

        Apotheke apotheke = apothekePort.findById(apothekeId);

        if (abeZertifikatPort.findABEZertifikatByApothekeId(apothekeId) == null) {
            ABEZertifikat abeZertifikat = ABEZertifikat.builder().
                    name(apotheke.getName() +"_"+ LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))).
                    type(zertifikat.getContentType()).
                    data(zertifikat.getBytes()).
                    build();
            abeZertifikat = abeZertifikatPort.save(abeZertifikat);
            abeZertifikatPort.setApothekeInABEZertifikat(abeZertifikat, apotheke);
            return abeZertifikat;
        }
        ABEZertifikat abeZertifikat = abeZertifikatPort.findABEZertifikatByApothekeId(apothekeId);
        abeZertifikat.setName(apotheke.getName() +"_"+ LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        abeZertifikat.setType(zertifikat.getContentType());
        abeZertifikat.setData(zertifikat.getBytes());
        abeZertifikatPort.setApothekeInABEZertifikat(abeZertifikat, apotheke);
        return abeZertifikat;
    }

    @Override
    public List<ABEZertifikatDTO> fetchAllAbeZertifikate() {

        return abeZertifikatPort.findAll().map(dbFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder.
                    fromCurrentContextPath().
                    path("/zertifikat/").
                    path(dbFile.getId()+"").
                    toUriString();
            return new ABEZertifikatDTO(dbFile.getName(), fileDownloadUri, dbFile.getType(), dbFile.getData().length, dbFile.getApotheke());
        }).collect(Collectors.toList());

    }
}
