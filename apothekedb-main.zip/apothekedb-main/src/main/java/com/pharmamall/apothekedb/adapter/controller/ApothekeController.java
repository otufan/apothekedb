package com.pharmamall.apothekedb.adapter.controller;

import com.pharmamall.apothekedb.application.port.dto.ApothekeDTO;
import com.pharmamall.apothekedb.application.filter.ApothekeFilter;
import com.pharmamall.apothekedb.application.port.in.ApothekeUseCase;
import com.pharmamall.apothekedb.application.port.in.InhaberUseCase;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@Produces(MediaType.APPLICATION_JSON)
@RequestMapping("/")
public class ApothekeController {

    private final ApothekeUseCase apothekeUseCase;
    private final InhaberUseCase inhaberUseCase;

    @PostMapping("/apotheke")
    public ResponseEntity<Map<String, Boolean>> registerApotheke(@Valid @RequestBody ApothekeDTO apothekeDTO) {

        apothekeUseCase.createApotheke(apothekeDTO);
        Map<String, Boolean> map = new HashMap<>();
        map.put("Apotheke ist erfolgreich erstellt!", true);
        return new ResponseEntity<>(map, HttpStatus.CREATED);
    }

    @GetMapping("/apotheke/{id}")
    public ResponseEntity<ApothekeDTO> getApotheke(@PathVariable Long id) {

        ApothekeDTO apothekeDTO = apothekeUseCase.findById(id);
        return new ResponseEntity<>(apothekeDTO, HttpStatus.OK);
    }

    @GetMapping("/apotheke/all")
    public ResponseEntity<List<ApothekeDTO>> getAllApotheken() {

        List<ApothekeDTO> apothekeList = apothekeUseCase.fetchAllApotheken();
        return new ResponseEntity<>(apothekeList, HttpStatus.OK);
    }

    @PutMapping("/apotheke/{id}")
    public ResponseEntity<Map<String, Boolean>> updateApotheke(@PathVariable Long id, @Valid @RequestBody ApothekeDTO apothekeDTO) {

        apothekeUseCase.updateApotheke(id, apothekeDTO);
        Map<String, Boolean> map = new HashMap<>();
        map.put("erfolgreich!", true);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    @DeleteMapping("/apotheke/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteApotheke(@PathVariable Long id) {

        apothekeUseCase.removeById(id);

        Map<String, Boolean> map = new HashMap<>();
        map.put("erfolgreich!", true);

        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    @DeleteMapping("/apotheke/{apothekeId}/delete/{inhaberId}")
    public ResponseEntity<Map<String, Boolean>> deleteInhaber(@PathVariable Long apothekeId, @PathVariable Long inhaberId) {

        inhaberUseCase.removeInhaberById(apothekeId, inhaberId);
        Map<String, Boolean> map = new HashMap<>();
        map.put("erfolgreich!", true);
        return new ResponseEntity<>(map, HttpStatus.OK);

    }

    @GetMapping("/apotheke/filter")
    public ResponseEntity<List<ApothekeDTO>> filterWithValue(@RequestBody ApothekeFilter apothekeFilter) {

        List<ApothekeDTO> apothekeDTOList = apothekeUseCase.fetchAllApothekenWithValue(apothekeFilter);
        return new ResponseEntity<>(apothekeDTOList, HttpStatus.OK);
    }

}
