package com.pharmamall.apothekedb.adapter.storage;

import com.pharmamall.apothekedb.adapter.storage.entity.ValidationEntity;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ApothekeMapper;
import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ValidationMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.ValidationRepository;
import com.pharmamall.apothekedb.annotations.Adapter;
import com.pharmamall.apothekedb.application.port.out.ValidationPort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.domain.Validation;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
@Adapter("persistence")
public class ValidationAdapter implements ValidationPort {

    private final ValidationRepository validationRepository;
    private final ValidationMapper validationMapper;
    private final ApothekeMapper apothekeMapper;

    @Override
    public void save(Validation validation, Apotheke apotheke) {

        ValidationEntity validationEntity = validationRepository.save(validationMapper.mapToValidationEntity(validation));

        validationRepository.setApotheke(validationEntity.getId(), apothekeMapper.mapToApothekeEntity(apotheke));
    }

    @Override
    public List<Validation> findAllValidation() {

        return validationMapper.mapToValidationList(validationRepository.findAll());

    }

    @Override
    public Validation findById(Long id) {
        return validationMapper.mapToValidation(validationRepository.findById(id).orElseThrow(()->new ResourceNotFoundException(String.format("Validation mit id %d ist nicht gefunden", id))));
    }

    @Override
    public void deleteById(Long id) {
        validationRepository.deleteById(id);
    }

    @Override
    public Validation findValidationByApothekeId(Long apothekeId) {
        return validationMapper.mapToValidation(validationRepository.findValidationByApothekeId(apothekeId));
    }
}
