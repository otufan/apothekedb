package com.pharmamall.apothekedb.adapter.storage;

import com.pharmamall.apothekedb.adapter.storage.entity.mapper.InhaberMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.InhaberRepository;
import com.pharmamall.apothekedb.annotations.Adapter;
import com.pharmamall.apothekedb.application.port.out.InhaberPort;
import com.pharmamall.apothekedb.domain.Inhaber;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@AllArgsConstructor
@Component
@Adapter("persistence")
public class InhaberAdapter implements InhaberPort {

    private final InhaberRepository inhaberRepository;
    private final InhaberMapper mapper;

    @Override
    public Inhaber write(Inhaber inhaber) {

        return mapper.mapToInhaber(inhaberRepository.save(mapper.mapToInhaberEntity(inhaber)));
    }

    @Override
    public Inhaber findById(Long id) {
        return mapper.mapToInhaber(inhaberRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException(String.format("Inhaber mit id %d ist nicht gefunden", id))));
    }

    @Override
    public void deleteById(Long id) {
        inhaberRepository.deleteById(id);
    }

    @Override
    public List<Inhaber> findAll() {
        return mapper.mapToInhaberList(inhaberRepository.findAll());
    }

    @Override
    public boolean existsInhaberBySteuerNummer(String steuerNummer) {
        return inhaberRepository.existsBySteuerNummer(steuerNummer);
    }

    @Override
    public Inhaber findBySteuerNummer(String steuerNummer) {
        return mapper.mapToInhaber(inhaberRepository.findBySteuerNummer(steuerNummer));
    }
}
