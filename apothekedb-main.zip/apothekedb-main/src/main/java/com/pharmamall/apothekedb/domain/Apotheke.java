package com.pharmamall.apothekedb.domain;

import com.pharmamall.apothekedb.annotations.DomainModel;

import com.pharmamall.apothekedb.domain.enumeration.ApothekeGruppen;
import java.util.List;
import lombok.*;


@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@DomainModel
public class Apotheke {

    private Long id;

    private String name;

    private String strasse;

    private String plz;

    private String ort;

    private String telefonNummer;

    private String email;

    private ApothekeGruppen apothekeGruppe;

    private List<Inhaber> inhabers;

}
