package com.pharmamall.apothekedb.application.filter;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApothekeFilter {

    private ApothekeFilterParam key;
    private String value;


}
