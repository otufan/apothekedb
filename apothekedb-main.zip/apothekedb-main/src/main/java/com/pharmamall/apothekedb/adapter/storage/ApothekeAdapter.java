package com.pharmamall.apothekedb.adapter.storage;

import com.pharmamall.apothekedb.adapter.storage.entity.mapper.ApothekeMapper;
import com.pharmamall.apothekedb.adapter.storage.repository.ApothekeRepository;
import com.pharmamall.apothekedb.annotations.Adapter;
import com.pharmamall.apothekedb.application.port.out.ApothekePort;
import com.pharmamall.apothekedb.domain.Apotheke;
import com.pharmamall.apothekedb.application.port.exception.ResourceNotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;


@AllArgsConstructor
@Component
@Adapter("persistence")
public class ApothekeAdapter implements ApothekePort {

    private final ApothekeRepository apothekeRepository;
    private final ApothekeMapper mapper;

    @Override
    public void write(Apotheke apotheke) {
        apothekeRepository.save(mapper.mapToApothekeEntity(apotheke));
    }

    @Override
    public boolean existsByEmail(String email) {
        return apothekeRepository.existsByEmail(email);
    }

    @Override
    public Apotheke findByEmail(String email) {
        return mapper.mapToApotheke(apothekeRepository.findByEmail(email));
    }

    @Override
    public Apotheke findById(Long id) {
        return mapper.mapToApotheke(apothekeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException(String.format("Apotheke mit id %d ist nicht gefunden", id))));
    }

    @Override
    public void deleteById(Long id) {
        apothekeRepository.deleteById(id);
    }

    @Override
    public List<Apotheke> findAll() {

        return mapper.mapToApothekeList(apothekeRepository.findAll());
    }

    @Override
    public List<Apotheke> findByNameWithValue(String value) {

        return mapper.mapToApothekeList(apothekeRepository.findByNameWithValue(value));
    }

    @Override
    public List<Apotheke> findByStrasseWithValue(String value) {
        return mapper.mapToApothekeList(apothekeRepository.findByStrasseWithValue(value));
    }

    @Override
    public List<Apotheke> findByPlzWithValue(String value) {

        return mapper.mapToApothekeList(apothekeRepository.findByPlzWithValue(value));
    }

    @Override
    public List<Apotheke> findByOrtWithValue(String value) {

        return mapper.mapToApothekeList(apothekeRepository.findByOrtWithValue(value));
    }

    @Override
    public List<Apotheke> findByEmailWithValue(String value) {

        return mapper.mapToApothekeList(apothekeRepository.findByEmailWithValue(value));
    }

}
