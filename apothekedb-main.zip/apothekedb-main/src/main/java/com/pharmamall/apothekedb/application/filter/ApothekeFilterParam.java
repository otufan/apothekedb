package com.pharmamall.apothekedb.application.filter;

public enum ApothekeFilterParam {

        NAME,
        STRASSE,
        PLZ, ORT,
        EMAIL,
        APOTHEKE_GRUPPE
    }
