package com.pharmamall.apothekedb.adapter.controller;

import com.pharmamall.apothekedb.application.port.dto.ValidationDTO;
import com.pharmamall.apothekedb.application.port.in.ValidationUseCase;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@Produces(MediaType.APPLICATION_JSON)
@RequestMapping("/")
public class ValidationController {

    private final ValidationUseCase validationUseCase;

    @PostMapping("apotheke/{apothekeId}/validation")
    public ResponseEntity<Map<String, Boolean>> validateApotheke(@PathVariable Long apothekeId, @RequestBody ValidationDTO validationDTO) {

        validationUseCase.validateApotheke(validationDTO, apothekeId);

        Map<String, Boolean> map = new HashMap<>();
        map.put("Validation ist erfolgreich hinzugefügt!", true);
        return new ResponseEntity<>(map, HttpStatus.CREATED);
    }

    @GetMapping("validation/all")
    public ResponseEntity<List<ValidationDTO>> getAllValidation() {

        List<ValidationDTO> validationDTOList = validationUseCase.fetchAllValidation();
        return ResponseEntity.status(HttpStatus.OK).body(validationDTOList);
    }

    @DeleteMapping("validation/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteValidation(@PathVariable Long id) {

        validationUseCase.removeValidation(id);
        Map<String, Boolean> map = new HashMap<>();
        map.put("erfolgreich!", true);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }
}
