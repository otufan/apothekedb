package com.pharmamall.apothekedb.domain;

import com.pharmamall.apothekedb.annotations.DomainModel;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@DomainModel
public class Inhaber {

    private Long id;

    private String vorname;

    private String nachname;

    private String steuerNummer;

    private LocalDate geburtsdatum;

    private String geburtsort;

}
